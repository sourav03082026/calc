# Git Upload And Cloudflare Setup

Use this package as the source repository for the CTC application.

## One-time GitHub setup

1. Create a private GitHub repository.
2. Extract this ZIP locally.
3. Upload the extracted contents of `ctc-secure-angular` to the repository.
4. Keep the repository private.

## Cloudflare Pages setup

Use these settings when connecting the GitHub repository to Cloudflare Pages:

- Framework preset: Angular, or None
- Root directory: `frontend`
- Build command: `npm ci && npm run build`
- Build output directory: `dist/ctc-secure-frontend/browser`

## Important

- Do not upload `node_modules`.
- Do not upload generated `dist` files.
- The frontend contains only the Supabase publishable key.
- Service-role keys must stay only in Supabase Edge Function environment variables.

