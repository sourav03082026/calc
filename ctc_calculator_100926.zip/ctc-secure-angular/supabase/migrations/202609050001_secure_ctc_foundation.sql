begin;

create extension if not exists pgcrypto with schema extensions;
create schema if not exists private;
revoke all on schema private from public, anon;
grant usage on schema private to authenticated;

create type public.app_role as enum ('organization_admin','recruiter','payroll_administrator','chro');
create type public.record_status as enum ('draft','finalized','superseded','cancelled');
create type public.job_status as enum ('queued','processing','ready','failed');

create table public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  logo_path text,
  country_code text not null default 'IN',
  created_at timestamptz not null default now(),
  created_by uuid not null references auth.users(id)
);

create table public.organization_members (
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  created_by uuid references auth.users(id),
  primary key (organization_id,user_id)
);

create table public.states (
  country_code text not null,
  code text not null,
  name text not null,
  active boolean not null default true,
  primary key(country_code,code)
);

create table public.professional_tax_schemes (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid references public.organizations(id) on delete cascade,
  state_code text not null,
  name text not null,
  effective_from date not null,
  effective_to date,
  salary_basis text not null default 'monthly_gross',
  source_url text,
  active boolean not null default true,
  check (effective_to is null or effective_to >= effective_from)
);

create table public.professional_tax_slabs (
  id uuid primary key default gen_random_uuid(),
  scheme_id uuid not null references public.professional_tax_schemes(id) on delete cascade,
  lower_bound numeric(18,6) not null,
  upper_bound numeric(18,6),
  lower_inclusive boolean not null default false,
  upper_inclusive boolean not null default true,
  deduction_amount numeric(18,6) not null,
  deduction_month smallint,
  sequence integer not null,
  check (upper_bound is null or upper_bound >= lower_bound),
  unique(scheme_id,sequence)
);

create table public.statutory_rule_sets (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid references public.organizations(id) on delete cascade,
  state_code text,
  name text not null,
  effective_from date not null,
  effective_to date,
  settings jsonb not null default '{}'::jsonb,
  source_urls jsonb not null default '[]'::jsonb,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  created_by uuid references auth.users(id),
  check (effective_to is null or effective_to >= effective_from)
);

create table public.salary_structures (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid references public.organizations(id) on delete cascade,
  code text not null,
  name text not null,
  description text,
  active boolean not null default true,
  unique nulls not distinct (organization_id,code)
);

create table public.salary_structure_versions (
  id uuid primary key default gen_random_uuid(),
  structure_id uuid not null references public.salary_structures(id) on delete cascade,
  version_no integer not null,
  effective_from date not null,
  effective_to date,
  parameters jsonb not null default '{}'::jsonb,
  declarations_schema jsonb not null default '{}'::jsonb,
  source_hash text not null,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  unique(structure_id,version_no),
  check (effective_to is null or effective_to >= effective_from)
);

create table public.salary_components (
  id uuid primary key default gen_random_uuid(),
  structure_version_id uuid not null references public.salary_structure_versions(id) on delete cascade,
  component_key text not null,
  label text not null,
  sequence integer not null,
  expression jsonb not null,
  component_type text not null,
  include_in_gross boolean not null default false,
  include_in_ctc boolean not null default false,
  employee_deduction boolean not null default false,
  visible boolean not null default true,
  unique(structure_version_id,component_key),
  unique(structure_version_id,sequence)
);

create table public.candidates (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  owner_user_id uuid not null references auth.users(id),
  assigned_user_id uuid references auth.users(id),
  candidate_name text not null,
  date_of_birth date,
  company text not null,
  grade text,
  qualification text,
  experience_months integer,
  designation text,
  department text,
  date_of_joining date,
  state_code text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.ctc_cases (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  candidate_id uuid not null references public.candidates(id) on delete cascade,
  owner_user_id uuid not null references auth.users(id),
  structure_version_id uuid not null references public.salary_structure_versions(id),
  status public.record_status not null default 'draft',
  inputs jsonb not null default '{}'::jsonb,
  calculated_result jsonb,
  version integer not null default 1,
  offer_reference text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  finalized_at timestamptz,
  finalized_by uuid references auth.users(id),
  unique nulls not distinct (organization_id,offer_reference)
);

create table public.ctc_snapshots (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  case_id uuid not null references public.ctc_cases(id),
  revision integer not null,
  candidate_snapshot jsonb not null,
  input_snapshot jsonb not null,
  rules_snapshot jsonb not null,
  result_snapshot jsonb not null,
  structure_snapshot jsonb not null,
  finalized_at timestamptz not null default now(),
  finalized_by uuid not null references auth.users(id),
  supersedes_snapshot_id uuid references public.ctc_snapshots(id),
  unique(case_id,revision)
);

create table public.offer_templates (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null,
  version integer not null,
  storage_path text not null,
  placeholder_schema jsonb not null default '{}'::jsonb,
  active boolean not null default false,
  created_at timestamptz not null default now(),
  created_by uuid not null references auth.users(id),
  unique(organization_id,name,version)
);

create table public.document_jobs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  snapshot_id uuid not null references public.ctc_snapshots(id),
  template_id uuid references public.offer_templates(id),
  requested_by uuid not null references auth.users(id),
  idempotency_key text not null,
  status public.job_status not null default 'queued',
  attempt_count integer not null default 0,
  last_error text,
  created_at timestamptz not null default now(),
  started_at timestamptz,
  completed_at timestamptz,
  unique(organization_id,idempotency_key)
);

create table public.secure_documents (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  snapshot_id uuid not null references public.ctc_snapshots(id),
  job_id uuid not null unique references public.document_jobs(id),
  storage_path text not null unique,
  cipher_algorithm text not null,
  encrypted_data_key text not null,
  nonce text not null,
  auth_tag text not null,
  content_sha256 text not null,
  created_at timestamptz not null default now(),
  created_by uuid not null references auth.users(id)
);

create table public.audit_events (
  id bigint generated always as identity primary key,
  organization_id uuid not null references public.organizations(id) on delete cascade,
  actor_user_id uuid references auth.users(id),
  event_type text not null,
  entity_type text not null,
  entity_id uuid,
  metadata jsonb not null default '{}'::jsonb,
  occurred_at timestamptz not null default now()
);

create index organization_members_user_idx on public.organization_members(user_id,active);
create index candidates_org_owner_idx on public.candidates(organization_id,owner_user_id);
create index candidates_joining_idx on public.candidates(organization_id,date_of_joining);
create index ctc_cases_org_status_idx on public.ctc_cases(organization_id,status,updated_at desc);
create index snapshots_org_finalized_idx on public.ctc_snapshots(organization_id,finalized_at desc);
create index jobs_status_idx on public.document_jobs(status,created_at) where status in ('queued','processing','failed');
create index audit_org_time_idx on public.audit_events(organization_id,occurred_at desc);

create or replace function private.has_org_role(p_org uuid, p_roles public.app_role[])
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.organization_members m
    where m.organization_id=p_org and m.user_id=(select auth.uid())
      and m.active and m.role=any(p_roles)
  )
$$;
revoke all on function private.has_org_role(uuid,public.app_role[]) from public,anon;
grant execute on function private.has_org_role(uuid,public.app_role[]) to authenticated;

create or replace function private.can_access_owned_record(p_org uuid,p_owner uuid,p_assigned uuid default null)
returns boolean language sql stable security definer set search_path = '' as $$
  select (select auth.uid()) is not null and (
    p_owner=(select auth.uid()) or p_assigned=(select auth.uid()) or
    private.has_org_role(p_org,array['organization_admin','payroll_administrator','chro']::public.app_role[])
  )
$$;
revoke all on function private.can_access_owned_record(uuid,uuid,uuid) from public,anon;
grant execute on function private.can_access_owned_record(uuid,uuid,uuid) to authenticated;

alter table public.organizations enable row level security;
alter table public.organization_members enable row level security;
alter table public.states enable row level security;
alter table public.professional_tax_schemes enable row level security;
alter table public.professional_tax_slabs enable row level security;
alter table public.statutory_rule_sets enable row level security;
alter table public.salary_structures enable row level security;
alter table public.salary_structure_versions enable row level security;
alter table public.salary_components enable row level security;
alter table public.candidates enable row level security;
alter table public.ctc_cases enable row level security;
alter table public.ctc_snapshots enable row level security;
alter table public.offer_templates enable row level security;
alter table public.document_jobs enable row level security;
alter table public.secure_documents enable row level security;
alter table public.audit_events enable row level security;

create policy organizations_select on public.organizations for select to authenticated
using (private.has_org_role(id,array['organization_admin','recruiter','payroll_administrator','chro']::public.app_role[]));
create policy members_select on public.organization_members for select to authenticated
using (user_id=(select auth.uid()) or private.has_org_role(organization_id,array['organization_admin','chro']::public.app_role[]));
create policy states_select on public.states for select to authenticated using (active);
create policy pt_schemes_select on public.professional_tax_schemes for select to authenticated
using (organization_id is null or private.has_org_role(organization_id,array['organization_admin','recruiter','payroll_administrator','chro']::public.app_role[]));
create policy pt_slabs_select on public.professional_tax_slabs for select to authenticated
using (exists(select 1 from public.professional_tax_schemes s where s.id=scheme_id and (s.organization_id is null or private.has_org_role(s.organization_id,array['organization_admin','recruiter','payroll_administrator','chro']::public.app_role[]))));
create policy rule_sets_select on public.statutory_rule_sets for select to authenticated
using (organization_id is null or private.has_org_role(organization_id,array['organization_admin','recruiter','payroll_administrator','chro']::public.app_role[]));
create policy structures_select on public.salary_structures for select to authenticated
using (organization_id is null or private.has_org_role(organization_id,array['organization_admin','recruiter','payroll_administrator','chro']::public.app_role[]));
create policy versions_select on public.salary_structure_versions for select to authenticated
using (exists(select 1 from public.salary_structures s where s.id=structure_id and (s.organization_id is null or private.has_org_role(s.organization_id,array['organization_admin','recruiter','payroll_administrator','chro']::public.app_role[]))));
create policy components_select on public.salary_components for select to authenticated
using (exists(select 1 from public.salary_structure_versions v join public.salary_structures s on s.id=v.structure_id where v.id=structure_version_id and (s.organization_id is null or private.has_org_role(s.organization_id,array['organization_admin','recruiter','payroll_administrator','chro']::public.app_role[]))));

create policy candidates_select on public.candidates for select to authenticated
using (private.can_access_owned_record(organization_id,owner_user_id,assigned_user_id));
create policy candidates_insert on public.candidates for insert to authenticated
with check (owner_user_id=(select auth.uid()) and private.has_org_role(organization_id,array['organization_admin','recruiter']::public.app_role[]));
create policy candidates_update on public.candidates for update to authenticated
using (private.can_access_owned_record(organization_id,owner_user_id,assigned_user_id))
with check (private.can_access_owned_record(organization_id,owner_user_id,assigned_user_id));

create policy cases_select on public.ctc_cases for select to authenticated
using (private.can_access_owned_record(organization_id,owner_user_id,null));
create policy cases_insert on public.ctc_cases for insert to authenticated
with check (owner_user_id=(select auth.uid()) and private.has_org_role(organization_id,array['organization_admin','recruiter']::public.app_role[]));
create policy cases_update_drafts on public.ctc_cases for update to authenticated
using (status='draft' and private.can_access_owned_record(organization_id,owner_user_id,null))
with check (status='draft' and private.can_access_owned_record(organization_id,owner_user_id,null));

create policy snapshots_select on public.ctc_snapshots for select to authenticated
using (exists(select 1 from public.ctc_cases c where c.id=case_id and private.can_access_owned_record(c.organization_id,c.owner_user_id,null)));
create policy templates_select on public.offer_templates for select to authenticated
using (private.has_org_role(organization_id,array['organization_admin','recruiter','payroll_administrator','chro']::public.app_role[]));
create policy templates_manage on public.offer_templates for all to authenticated
using (private.has_org_role(organization_id,array['organization_admin']::public.app_role[]))
with check (private.has_org_role(organization_id,array['organization_admin']::public.app_role[]));
create policy jobs_select on public.document_jobs for select to authenticated
using (exists(select 1 from public.ctc_snapshots s join public.ctc_cases c on c.id=s.case_id where s.id=snapshot_id and private.can_access_owned_record(c.organization_id,c.owner_user_id,null)));
create policy docs_select on public.secure_documents for select to authenticated
using (exists(select 1 from public.ctc_snapshots s join public.ctc_cases c on c.id=s.case_id where s.id=snapshot_id and private.can_access_owned_record(c.organization_id,c.owner_user_id,null)));
create policy audit_select on public.audit_events for select to authenticated
using (private.has_org_role(organization_id,array['organization_admin','payroll_administrator','chro']::public.app_role[]));

create policy admin_pt_schemes on public.professional_tax_schemes for all to authenticated
using (organization_id is not null and private.has_org_role(organization_id,array['organization_admin']::public.app_role[]))
with check (organization_id is not null and private.has_org_role(organization_id,array['organization_admin']::public.app_role[]));
create policy admin_rule_sets on public.statutory_rule_sets for all to authenticated
using (organization_id is not null and private.has_org_role(organization_id,array['organization_admin']::public.app_role[]))
with check (organization_id is not null and private.has_org_role(organization_id,array['organization_admin']::public.app_role[]));

create or replace function private.value_number(p_expr jsonb,p_ctx jsonb)
returns numeric language plpgsql stable security invoker set search_path='' as $$
declare
  op text:=p_expr->>'op'; a numeric; b numeric; item jsonb; result numeric; key text;
begin
  if op='const' then return (p_expr->>'value')::numeric; end if;
  if op in ('ref','input','param') then
    key:=p_expr->>'key';
    if not p_ctx ? key then raise exception 'Missing calculation value: %',key; end if;
    return (p_ctx->>key)::numeric;
  end if;
  if op='add' then result:=0; for item in select value from jsonb_array_elements(p_expr->'args') loop result:=result+private.value_number(item,p_ctx); end loop; return result; end if;
  if op='mul' then result:=1; for item in select value from jsonb_array_elements(p_expr->'args') loop result:=result*private.value_number(item,p_ctx); end loop; return result; end if;
  if op='sub' then return private.value_number(p_expr->'args'->0,p_ctx)-private.value_number(p_expr->'args'->1,p_ctx); end if;
  if op='div' then b:=private.value_number(p_expr->'args'->1,p_ctx); if b=0 then raise exception 'Division by zero'; end if; return private.value_number(p_expr->'args'->0,p_ctx)/b; end if;
  if op='max' then return greatest(private.value_number(p_expr->'args'->0,p_ctx),private.value_number(p_expr->'args'->1,p_ctx)); end if;
  if op='min' then return least(private.value_number(p_expr->'args'->0,p_ctx),private.value_number(p_expr->'args'->1,p_ctx)); end if;
  if op='round' then return round(private.value_number(p_expr->'arg',p_ctx),(p_expr->>'scale')::integer); end if;
  if op='if_eq' then
    if p_ctx->>(p_expr->>'key')=p_expr->>'value' then return private.value_number(p_expr->'then',p_ctx); else return private.value_number(p_expr->'else',p_ctx); end if;
  end if;
  if op='if_lte' then
    if private.value_number(p_expr->'left',p_ctx)<=private.value_number(p_expr->'right',p_ctx) then return private.value_number(p_expr->'then',p_ctx); else return private.value_number(p_expr->'else',p_ctx); end if;
  end if;
  if op='if_gt' then
    if private.value_number(p_expr->'left',p_ctx)>private.value_number(p_expr->'right',p_ctx) then return private.value_number(p_expr->'then',p_ctx); else return private.value_number(p_expr->'else',p_ctx); end if;
  end if;
  raise exception 'Unsupported calculation operation: %',op;
end $$;

create or replace function private.professional_tax(p_org uuid,p_state text,p_on date,p_salary numeric)
returns numeric language sql stable security invoker set search_path='' as $$
  with scheme as (
    select s.id from public.professional_tax_schemes s
    where s.state_code=p_state and s.active and s.effective_from<=p_on
      and (s.effective_to is null or s.effective_to>=p_on)
      and (s.organization_id=p_org or s.organization_id is null)
    order by (s.organization_id is not null) desc,s.effective_from desc limit 1
  )
  select coalesce((select sl.deduction_amount from public.professional_tax_slabs sl join scheme on scheme.id=sl.scheme_id
    where (case when sl.lower_inclusive then p_salary>=sl.lower_bound else p_salary>sl.lower_bound end)
      and (sl.upper_bound is null or case when sl.upper_inclusive then p_salary<=sl.upper_bound else p_salary<sl.upper_bound end)
      and (sl.deduction_month is null or sl.deduction_month=extract(month from p_on)::integer)
    order by sl.sequence limit 1),0)
$$;

create or replace function public.calculate_ctc(
  p_organization_id uuid,p_structure_version_id uuid,p_inputs jsonb,p_effective_date date,p_state_code text
) returns jsonb language plpgsql stable security invoker set search_path='' as $$
declare
  v_params jsonb; v_rules jsonb:='{}'::jsonb; v_ctx jsonb; v_components jsonb:='[]'::jsonb;
  v_row record; v_value numeric; v_gross numeric:=0; v_ctc numeric:=0; v_deductions numeric:=0;
  v_months numeric; v_pt numeric;
begin
  if not private.has_org_role(p_organization_id,array['organization_admin','recruiter','payroll_administrator','chro']::public.app_role[]) then raise exception 'Access denied'; end if;
  select v.parameters into v_params from public.salary_structure_versions v where v.id=p_structure_version_id and v.active and v.effective_from<=p_effective_date and (v.effective_to is null or v.effective_to>=p_effective_date);
  if v_params is null then raise exception 'No active structure version for effective date'; end if;
  select coalesce(r.settings,'{}'::jsonb) into v_rules from public.statutory_rule_sets r
    where r.active and r.effective_from<=p_effective_date and (r.effective_to is null or r.effective_to>=p_effective_date)
      and (r.organization_id=p_organization_id or r.organization_id is null) and (r.state_code=p_state_code or r.state_code is null)
    order by (r.organization_id is not null) desc,(r.state_code is not null) desc,r.effective_from desc limit 1;
  v_ctx:=coalesce(v_params,'{}'::jsonb)||coalesce(v_rules,'{}'::jsonb)||coalesce(p_inputs,'{}'::jsonb);
  v_months:=(v_ctx->>'months_per_year')::numeric;
  if v_months is null or v_months<=0 then raise exception 'months_per_year must be configured'; end if;
  for v_row in select * from public.salary_components where structure_version_id=p_structure_version_id order by sequence loop
    if v_row.expression->>'op'='professional_tax' then
      v_value:=private.professional_tax(p_organization_id,p_state_code,p_effective_date,(v_ctx->>(v_row.expression->>'salary_ref'))::numeric);
    else
      v_value:=private.value_number(v_row.expression,v_ctx);
    end if;
    v_ctx:=v_ctx||jsonb_build_object(v_row.component_key,v_value);
    if v_row.include_in_gross then v_gross:=v_gross+v_value; end if;
    if v_row.include_in_ctc then v_ctc:=v_ctc+v_value; end if;
    if v_row.employee_deduction then v_deductions:=v_deductions+v_value; end if;
    if v_row.visible then v_components:=v_components||jsonb_build_array(jsonb_build_object('key',v_row.component_key,'label',v_row.label,'type',v_row.component_type,'monthly_exact',v_value,'monthly_display',round(v_value,0),'annual_exact',v_value*v_months)); end if;
  end loop;
  return jsonb_build_object('components',v_components,'monthly_gross',v_gross,'annual_gross',v_gross*v_months,'monthly_ctc',v_ctc,'annual_ctc',v_ctc*v_months,'monthly_deductions',v_deductions,'net_take_home',v_gross-v_deductions,'context',v_ctx);
end $$;

create or replace function public.save_ctc_draft(p_case_id uuid,p_expected_version integer,p_inputs jsonb)
returns public.ctc_cases language plpgsql security invoker set search_path='' as $$
declare v_case public.ctc_cases;
begin
  update public.ctc_cases set inputs=p_inputs,version=version+1,updated_at=now()
  where id=p_case_id and status='draft' and version=p_expected_version returning * into v_case;
  if v_case.id is null then raise exception 'Draft changed or is no longer editable'; end if;
  return v_case;
end $$;

create or replace function public.finalize_ctc_case(p_case_id uuid,p_expected_version integer,p_idempotency_key text)
returns uuid language plpgsql security invoker set search_path='' as $$
declare v_case public.ctc_cases; v_candidate public.candidates; v_snapshot uuid; v_rules jsonb; v_structure jsonb; v_revision integer;
begin
  select * into v_case from public.ctc_cases where id=p_case_id for update;
  if v_case.id is null or v_case.status<>'draft' or v_case.version<>p_expected_version then raise exception 'Draft changed or cannot be finalized'; end if;
  if v_case.calculated_result is null then raise exception 'A verified server calculation is required'; end if;
  select * into v_candidate from public.candidates where id=v_case.candidate_id;
  if v_candidate.id is null then raise exception 'Candidate not found'; end if;
  select coalesce(max(revision),0)+1 into v_revision from public.ctc_snapshots where case_id=p_case_id;
  select to_jsonb(r) into v_rules from public.statutory_rule_sets r where r.active and r.effective_from<=coalesce(v_candidate.date_of_joining,current_date) and (r.effective_to is null or r.effective_to>=coalesce(v_candidate.date_of_joining,current_date)) and (r.organization_id=v_case.organization_id or r.organization_id is null) and (r.state_code=v_candidate.state_code or r.state_code is null) order by (r.organization_id is not null) desc,(r.state_code is not null) desc,r.effective_from desc limit 1;
  select jsonb_build_object('version',to_jsonb(v),'structure',to_jsonb(s),'components',coalesce(jsonb_agg(to_jsonb(c) order by c.sequence),'[]'::jsonb)) into v_structure
    from public.salary_structure_versions v join public.salary_structures s on s.id=v.structure_id left join public.salary_components c on c.structure_version_id=v.id where v.id=v_case.structure_version_id group by v.id,s.id;
  insert into public.ctc_snapshots(organization_id,case_id,revision,candidate_snapshot,input_snapshot,rules_snapshot,result_snapshot,structure_snapshot,finalized_by)
  values(v_case.organization_id,v_case.id,v_revision,to_jsonb(v_candidate),v_case.inputs,coalesce(v_rules,'{}'::jsonb),v_case.calculated_result,v_structure,(select auth.uid())) returning id into v_snapshot;
  update public.ctc_cases set status='finalized',finalized_at=now(),finalized_by=(select auth.uid()),version=version+1,updated_at=now() where id=v_case.id;
  insert into public.document_jobs(organization_id,snapshot_id,requested_by,idempotency_key) values(v_case.organization_id,v_snapshot,(select auth.uid()),p_idempotency_key);
  insert into public.audit_events(organization_id,actor_user_id,event_type,entity_type,entity_id,metadata) values(v_case.organization_id,(select auth.uid()),'ctc.finalized','ctc_snapshot',v_snapshot,jsonb_build_object('case_id',v_case.id,'revision',v_revision));
  return v_snapshot;
end $$;

create or replace function public.bootstrap_organization(p_name text)
returns uuid language plpgsql security definer set search_path='' as $$
declare v_user uuid:=(select auth.uid()); v_org uuid;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  if exists(select 1 from public.organization_members where user_id=v_user) then raise exception 'User already belongs to an organization'; end if;
  insert into public.organizations(name,created_by) values(p_name,v_user) returning id into v_org;
  insert into public.organization_members(organization_id,user_id,role,created_by) values(v_org,v_user,'organization_admin',v_user);
  return v_org;
end $$;
revoke all on function public.bootstrap_organization(text) from public,anon;
grant execute on function public.bootstrap_organization(text) to authenticated;

create view public.payroll_monthly_summary with (security_invoker=true) as
select s.organization_id,date_trunc('month',(s.candidate_snapshot->>'date_of_joining')::date)::date joining_month,
 count(*) finalized_count,sum((s.result_snapshot->>'monthly_ctc')::numeric) monthly_ctc,
 sum((s.result_snapshot->>'monthly_gross')::numeric) monthly_gross,sum((s.result_snapshot->>'net_take_home')::numeric) net_take_home
from public.ctc_snapshots s group by s.organization_id,date_trunc('month',(s.candidate_snapshot->>'date_of_joining')::date)::date;

create view public.chro_ctc_trends with (security_invoker=true) as
select s.organization_id,date_trunc('month',s.finalized_at)::date finalized_month,
 count(*) offers,avg((s.result_snapshot->>'annual_ctc')::numeric) average_annual_ctc,
 percentile_cont(0.5) within group(order by (s.result_snapshot->>'annual_ctc')::numeric) median_annual_ctc,
 sum((s.result_snapshot->>'annual_ctc')::numeric) total_annual_ctc
from public.ctc_snapshots s group by s.organization_id,date_trunc('month',s.finalized_at)::date;

revoke all on all tables in schema public from anon;
grant select on public.states,public.salary_structures,public.salary_structure_versions,public.salary_components to authenticated;
grant select,insert,update on public.candidates,public.ctc_cases to authenticated;
grant select on public.organizations,public.organization_members,public.professional_tax_schemes,public.professional_tax_slabs,public.statutory_rule_sets,public.ctc_snapshots,public.offer_templates,public.document_jobs,public.secure_documents,public.audit_events,public.payroll_monthly_summary,public.chro_ctc_trends to authenticated;
grant insert,update,delete on public.offer_templates,public.professional_tax_schemes,public.statutory_rule_sets to authenticated;
grant execute on function public.calculate_ctc(uuid,uuid,jsonb,date,text),public.save_ctc_draft(uuid,integer,jsonb),public.finalize_ctc_case(uuid,integer,text) to authenticated;

insert into public.states(country_code,code,name) values
('IN','AN','Andaman and Nicobar Islands'),('IN','AP','Andhra Pradesh'),('IN','AR','Arunachal Pradesh'),('IN','AS','Assam'),('IN','BR','Bihar'),('IN','CH','Chandigarh'),('IN','CG','Chhattisgarh'),('IN','DN','Dadra and Nagar Haveli and Daman and Diu'),('IN','DL','Delhi'),('IN','GA','Goa'),('IN','GJ','Gujarat'),('IN','HR','Haryana'),('IN','HP','Himachal Pradesh'),('IN','JK','Jammu and Kashmir'),('IN','JH','Jharkhand'),('IN','KA','Karnataka'),('IN','KL','Kerala'),('IN','LA','Ladakh'),('IN','LD','Lakshadweep'),('IN','MP','Madhya Pradesh'),('IN','MH','Maharashtra'),('IN','MN','Manipur'),('IN','ML','Meghalaya'),('IN','MZ','Mizoram'),('IN','NL','Nagaland'),('IN','OD','Odisha'),('IN','PY','Puducherry'),('IN','PB','Punjab'),('IN','RJ','Rajasthan'),('IN','SK','Sikkim'),('IN','TN','Tamil Nadu'),('IN','TS','Telangana'),('IN','TR','Tripura'),('IN','UP','Uttar Pradesh'),('IN','UK','Uttarakhand'),('IN','WB','West Bengal');

with s as (
 insert into public.professional_tax_schemes(organization_id,state_code,name,effective_from,source_url)
 values(null,'WB','West Bengal employee professional tax','2016-08-01','https://professiontax.wb.gov.in/') returning id
) insert into public.professional_tax_slabs(scheme_id,lower_bound,upper_bound,lower_inclusive,upper_inclusive,deduction_amount,sequence)
select id,0,10000,true,true,0,1 from s union all
select id,10000,15000,false,true,110,2 from s union all
select id,15000,25000,false,true,130,3 from s union all
select id,25000,40000,false,true,150,4 from s union all
select id,40000,null,false,true,200,5 from s;

insert into public.statutory_rule_sets(organization_id,state_code,name,effective_from,settings,source_urls)
values(null,null,'Default configurable statutory parameters','2026-01-01',
 '{"months_per_year":12,"basic_pct":0.5,"hra_pct":0.5,"pf_rate":0.12,"pf_wage_cap":15000,"minimum_monthly_ctc":12000,"bonus_eligibility_ceiling":21000,"mediclaim_annual":3900,"esic_employee_rate":0.0075,"esic_employer_rate":0.0325,"esic_wage_ceiling":21000}'::jsonb,
 '["https://www.epfindia.gov.in/","https://www.esic.gov.in/"]'::jsonb);

-- Structure definitions and every business value live in data, never in the evaluator.
with st as (
 insert into public.salary_structures(organization_id,code,name,description) values(null,'STRUCTURE_1','Structure 1','Special Allowance balancing mechanism from approved workbook') returning id
), sv as (
 insert into public.salary_structure_versions(structure_id,version_no,effective_from,parameters,declarations_schema,source_hash)
 select id,1,'2026-01-01','{}'::jsonb,'{"required":["monthly_ctc","minimum_wage_monthly","benefit_mode","bonus_mode"],"enums":{"benefit_mode":["MEDICLAIM","ESIC"],"bonus_mode":["ANNUAL","OFF"]}}'::jsonb,'16d5f0dd6d18fc25c52baf63bd5f2e0878eaa11cdbaf9b2b005267da82c75c2d' from st returning id
) insert into public.salary_components(structure_version_id,component_key,label,sequence,expression,component_type,include_in_gross,include_in_ctc,employee_deduction)
select id,x.component_key,x.label,x.sequence,x.expression::jsonb,x.component_type,x.in_gross,x.in_ctc,x.deduction from sv cross join (values
 ('basic_salary','Basic Salary',10,'{"op":"mul","args":[{"op":"input","key":"monthly_ctc"},{"op":"param","key":"basic_pct"}]}','earning',true,true,false),
 ('hra','HRA',20,'{"op":"mul","args":[{"op":"ref","key":"basic_salary"},{"op":"param","key":"hra_pct"}]}','earning',true,true,false),
 ('annual_bonus','Annual Bonus',30,'{"op":"if_eq","key":"bonus_mode","value":"ANNUAL","then":{"op":"div","args":[{"op":"ref","key":"basic_salary"},{"op":"param","key":"months_per_year"}]},"else":{"op":"const","value":0}}','earning',false,true,false),
 ('advance_bonus','Advance Bonus',40,'{"op":"if_eq","key":"bonus_mode","value":"ANNUAL","then":{"op":"max","args":[{"op":"const","value":0},{"op":"sub","args":[{"op":"input","key":"minimum_wage_monthly"},{"op":"div","args":[{"op":"ref","key":"basic_salary"},{"op":"param","key":"months_per_year"}]}]}]},"else":{"op":"const","value":0}}','earning',true,true,false),
 ('special_allowance','Special Allowance',50,'{"op":"if_eq","key":"benefit_mode","value":"ESIC","then":{"op":"div","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"input","key":"monthly_ctc"},{"op":"ref","key":"basic_salary"}]},{"op":"ref","key":"hra"}]},{"op":"ref","key":"annual_bonus"}]},{"op":"ref","key":"advance_bonus"}]},{"op":"add","args":[{"op":"mul","args":[{"op":"param","key":"pf_rate"},{"op":"ref","key":"basic_salary"}]},{"op":"mul","args":[{"op":"param","key":"esic_employer_rate"},{"op":"add","args":[{"op":"ref","key":"basic_salary"},{"op":"ref","key":"hra"},{"op":"ref","key":"advance_bonus"}]}]}]}]},{"op":"add","args":[{"op":"const","value":1},{"op":"param","key":"pf_rate"},{"op":"param","key":"esic_employer_rate"}]}]},"else":{"op":"div","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"input","key":"monthly_ctc"},{"op":"ref","key":"basic_salary"}]},{"op":"ref","key":"hra"}]},{"op":"ref","key":"annual_bonus"}]},{"op":"ref","key":"advance_bonus"}]},{"op":"div","args":[{"op":"param","key":"mediclaim_annual"},{"op":"param","key":"months_per_year"}]}]},{"op":"add","args":[{"op":"const","value":1},{"op":"param","key":"pf_rate"}]}]}}','earning',true,true,false),
 ('pf_wages','PF Wages',60,'{"op":"add","args":[{"op":"ref","key":"basic_salary"},{"op":"ref","key":"special_allowance"}]}','reference',false,false,false),
 ('employer_pf','Employer PF Contribution',70,'{"op":"mul","args":[{"op":"ref","key":"pf_wages"},{"op":"param","key":"pf_rate"}]}','employer_contribution',false,true,false),
 ('employer_benefit','ESIC / Mediclaim',80,'{"op":"if_eq","key":"benefit_mode","value":"ESIC","then":{"op":"mul","args":[{"op":"add","args":[{"op":"ref","key":"basic_salary"},{"op":"ref","key":"hra"},{"op":"ref","key":"advance_bonus"},{"op":"ref","key":"special_allowance"}]},{"op":"param","key":"esic_employer_rate"}]},"else":{"op":"div","args":[{"op":"param","key":"mediclaim_annual"},{"op":"param","key":"months_per_year"}]}}','employer_contribution',false,true,false),
 ('employee_pf','Employee PF Deduction',90,'{"op":"ref","key":"employer_pf"}','deduction',false,false,true),
 ('employee_esic','Employee ESIC Deduction',100,'{"op":"if_eq","key":"benefit_mode","value":"ESIC","then":{"op":"mul","args":[{"op":"add","args":[{"op":"ref","key":"basic_salary"},{"op":"ref","key":"hra"},{"op":"ref","key":"advance_bonus"},{"op":"ref","key":"special_allowance"}]},{"op":"param","key":"esic_employee_rate"}]},"else":{"op":"const","value":0}}','deduction',false,false,true),
 ('professional_tax','Professional Tax',110,'{"op":"professional_tax","salary_ref":"monthly_gross_base"}','deduction',false,false,true)
) as x(component_key,label,sequence,expression,component_type,in_gross,in_ctc,deduction);

-- A hidden gross reference is added after earnings and before state-wise P-Tax resolution.
update public.salary_components set sequence=105,visible=false,component_key='monthly_gross_base',label='Monthly Gross Base',expression='{"op":"add","args":[{"op":"ref","key":"basic_salary"},{"op":"ref","key":"hra"},{"op":"ref","key":"advance_bonus"},{"op":"ref","key":"special_allowance"}]}'::jsonb,component_type='reference',include_in_gross=false,include_in_ctc=false,employee_deduction=false
where false;
-- Explicit insert avoids embedding any monetary value; it only defines the calculation graph.
insert into public.salary_components(structure_version_id,component_key,label,sequence,expression,component_type,visible)
select v.id,'monthly_gross_base','Monthly Gross Base',105,'{"op":"add","args":[{"op":"ref","key":"basic_salary"},{"op":"ref","key":"hra"},{"op":"ref","key":"advance_bonus"},{"op":"ref","key":"special_allowance"}]}'::jsonb,'reference',false
from public.salary_structure_versions v join public.salary_structures s on s.id=v.structure_id where s.code='STRUCTURE_1' and v.version_no=1;

-- Move Professional Tax after the gross reference.
update public.salary_components c set sequence=120 where c.component_key='professional_tax' and exists(select 1 from public.salary_structure_versions v join public.salary_structures s on s.id=v.structure_id where v.id=c.structure_version_id and s.code='STRUCTURE_1');

-- Structure 2 is seeded in a following migration after its matrix-specific golden tests are loaded.

create or replace function private.reject_snapshot_mutation() returns trigger language plpgsql set search_path='' as $$ begin raise exception 'Finalized snapshots are immutable'; end $$;
create trigger immutable_ctc_snapshots before update or delete on public.ctc_snapshots for each row execute function private.reject_snapshot_mutation();
create trigger immutable_audit_events before update or delete on public.audit_events for each row execute function private.reject_snapshot_mutation();

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('offer-documents','offer-documents',false,10485760,array['application/octet-stream']) on conflict(id) do update set public=false;
create policy storage_offer_select_none on storage.objects for select to authenticated using(false);

commit;
