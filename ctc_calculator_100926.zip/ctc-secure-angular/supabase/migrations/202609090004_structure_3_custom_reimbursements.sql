begin;

create or replace function public.calculate_ctc_structure_3(
  p_organization_id uuid,
  p_structure_version_id uuid,
  p_inputs jsonb,
  p_effective_date date,
  p_state_code text
) returns jsonb
language plpgsql stable security invoker set search_path=''
as $$
declare
  v_structure_code text; v_fit public.structure_3_fitment_rules; v_rules jsonb;
  v_months numeric; v_monthly_ctc numeric; v_basic numeric; v_hra numeric;
  v_attire numeric; v_communication numeric; v_conveyance numeric; v_books numeric;
  v_entertainment numeric; v_meal numeric; v_lta numeric; v_bonus numeric;
  v_pf_wages numeric; v_employer_pf numeric; v_employer_benefit numeric;
  v_allowance numeric; v_gross numeric; v_employee_esic numeric; v_pt numeric;
  v_deductions numeric; v_components jsonb := '[]'::jsonb;
begin
  if not private.has_org_role(p_organization_id,array['organization_admin','recruiter','payroll_administrator','chro']::public.app_role[])
    then raise exception 'Access denied'; end if;

  select s.code into v_structure_code
  from public.salary_structure_versions v
  join public.salary_structures s on s.id=v.structure_id
  where v.id=p_structure_version_id and v.active and v.effective_from<=p_effective_date
    and (v.effective_to is null or v.effective_to>=p_effective_date);
  if v_structure_code is distinct from 'STRUCTURE_3' then raise exception 'Invalid Structure 3 version'; end if;

  select * into v_fit from public.structure_3_fitment_rules
  where grade=upper(trim(p_inputs->>'grade')) and active;
  if v_fit.id is null then raise exception 'Select a valid Structure 3 grade (L1 to L20)'; end if;

  select coalesce(r.settings,'{}'::jsonb) into v_rules
  from public.statutory_rule_sets r
  where r.active and r.effective_from<=p_effective_date
    and (r.effective_to is null or r.effective_to>=p_effective_date)
    and (r.organization_id=p_organization_id or r.organization_id is null)
    and (r.state_code=p_state_code or r.state_code is null)
  order by (r.organization_id is not null) desc,(r.state_code is not null) desc,r.effective_from desc
  limit 1;

  v_months := (v_rules->>'months_per_year')::numeric;
  v_monthly_ctc := (p_inputs->>'monthly_ctc')::numeric;
  if v_monthly_ctc < (v_rules->>'minimum_monthly_ctc')::numeric then
    raise exception 'Monthly CTC is below the configured minimum';
  end if;

  v_basic := v_monthly_ctc * (v_rules->>'basic_pct')::numeric;
  v_hra := v_basic * (v_rules->>'hra_pct')::numeric;

  v_attire := case when coalesce((p_inputs->>'opt_attire')::boolean,false)
    then coalesce(nullif(p_inputs->>'attire_monthly_custom','')::numeric,v_fit.attire_monthly) else 0 end;
  v_communication := case when coalesce((p_inputs->>'opt_communication')::boolean,false)
    then coalesce(nullif(p_inputs->>'communication_monthly_custom','')::numeric,v_fit.communication_monthly) else 0 end;
  v_conveyance := case when coalesce((p_inputs->>'opt_conveyance')::boolean,false)
    then coalesce(nullif(p_inputs->>'conveyance_monthly_custom','')::numeric,v_fit.conveyance_monthly) else 0 end;
  v_books := case when coalesce((p_inputs->>'opt_books')::boolean,false)
    then coalesce(nullif(p_inputs->>'books_monthly_custom','')::numeric,v_fit.books_monthly) else 0 end;
  v_entertainment := case when coalesce((p_inputs->>'opt_entertainment')::boolean,false)
    then coalesce(nullif(p_inputs->>'entertainment_annual_custom','')::numeric,v_fit.entertainment_annual)/v_months else 0 end;
  v_meal := case when coalesce((p_inputs->>'opt_meal_card')::boolean,false)
    then coalesce(nullif(p_inputs->>'meal_card_monthly_custom','')::numeric,v_fit.meal_card_monthly) else 0 end;

  if coalesce((p_inputs->>'opt_lta')::boolean,false) and not v_fit.lta_eligible then
    raise exception 'LTA is not available for the selected grade';
  end if;
  v_lta := case when coalesce((p_inputs->>'opt_lta')::boolean,false)
    then coalesce(nullif(p_inputs->>'lta_annual_custom','')::numeric,v_basic)/v_months else 0 end;

  if v_attire<0 or v_attire>v_fit.attire_monthly then raise exception 'Attire amount exceeds the grade-based maximum'; end if;
  if v_communication<0 or v_communication>v_fit.communication_monthly then raise exception 'Communication reimbursement exceeds the grade-based maximum'; end if;
  if v_conveyance<0 or v_conveyance>v_fit.conveyance_monthly then raise exception 'Conveyance reimbursement exceeds the grade-based maximum'; end if;
  if v_books<0 or v_books>v_fit.books_monthly then raise exception 'Books and Periodicals reimbursement exceeds the grade-based maximum'; end if;
  if v_entertainment<0 or v_entertainment*v_months>v_fit.entertainment_annual then raise exception 'Entertainment allowance exceeds the grade-based maximum'; end if;
  if v_meal<0 or v_meal>v_fit.meal_card_monthly then raise exception 'Meal Card amount exceeds the grade-based maximum'; end if;
  if v_lta<0 or v_lta*v_months>v_basic then raise exception 'LTA exceeds one month Basic for the selected CTC'; end if;

  v_bonus := case when p_inputs->>'bonus_mode'='ANNUAL' then v_basic/v_months else 0 end;
  v_pf_wages := case when p_inputs->>'pf_basis'='ACTUAL_WAGES' then v_basic else least((v_rules->>'pf_wage_cap')::numeric,v_basic) end;
  v_employer_pf := v_pf_wages * (v_rules->>'pf_rate')::numeric;

  if p_inputs->>'benefit_mode'='ESIC' then
    v_allowance := (v_monthly_ctc-v_basic-v_hra-v_attire-v_communication-v_conveyance-v_books-v_entertainment-v_meal-v_lta-v_bonus-v_employer_pf
      -(v_rules->>'esic_employer_rate')::numeric*(v_basic+v_hra+v_attire))/(1+(v_rules->>'esic_employer_rate')::numeric);
    v_gross := v_basic+v_hra+v_attire+v_allowance;
    v_employer_benefit := v_gross*(v_rules->>'esic_employer_rate')::numeric;
    v_employee_esic := v_gross*(v_rules->>'esic_employee_rate')::numeric;
  else
    v_employer_benefit := (p_inputs->>'mediclaim_annual')::numeric/v_months;
    v_employee_esic := 0;
    v_allowance := v_monthly_ctc-v_basic-v_hra-v_attire-v_communication-v_conveyance-v_books-v_entertainment-v_meal-v_lta-v_bonus-v_employer_pf-v_employer_benefit;
    v_gross := v_basic+v_hra+v_attire+v_allowance;
  end if;
  if v_allowance < 0 then raise exception 'Selected benefits exceed available CTC. Reduce one or more optional amounts.'; end if;

  v_pt := private.professional_tax(p_organization_id,p_state_code,p_effective_date,v_gross);
  v_deductions := v_employer_pf+v_employee_esic+v_pt;
  v_components := jsonb_build_array(
    jsonb_build_object('key','basic_salary','label','Basic Salary','type','earning','monthly_exact',v_basic,'monthly_display',round(v_basic),'annual_exact',v_basic*v_months),
    jsonb_build_object('key','hra','label','HRA','type','earning','monthly_exact',v_hra,'monthly_display',round(v_hra),'annual_exact',v_hra*v_months),
    jsonb_build_object('key','attire_allowance','label','Attire & Uniform Allowance','type','earning','monthly_exact',v_attire,'monthly_display',round(v_attire),'annual_exact',v_attire*v_months),
    jsonb_build_object('key','monthly_allowance','label','Monthly Allowance','type','earning','monthly_exact',v_allowance,'monthly_display',round(v_allowance),'annual_exact',v_allowance*v_months),
    jsonb_build_object('key','communication_reimbursement','label','Communication Reimbursement','type','reimbursement','monthly_exact',v_communication,'monthly_display',round(v_communication),'annual_exact',v_communication*v_months),
    jsonb_build_object('key','conveyance_reimbursement','label','Conveyance Reimbursement','type','reimbursement','monthly_exact',v_conveyance,'monthly_display',round(v_conveyance),'annual_exact',v_conveyance*v_months),
    jsonb_build_object('key','books_periodicals','label','Books & Periodicals','type','reimbursement','monthly_exact',v_books,'monthly_display',round(v_books),'annual_exact',v_books*v_months),
    jsonb_build_object('key','entertainment_allowance','label','Entertainment Allowance','type','reimbursement','monthly_exact',v_entertainment,'monthly_display',round(v_entertainment),'annual_exact',v_entertainment*v_months),
    jsonb_build_object('key','meal_card','label','Meal Card','type','reimbursement','monthly_exact',v_meal,'monthly_display',round(v_meal),'annual_exact',v_meal*v_months),
    jsonb_build_object('key','annual_bonus','label','Annual Bonus','type','annual_benefit','monthly_exact',v_bonus,'monthly_display',round(v_bonus),'annual_exact',v_bonus*v_months),
    jsonb_build_object('key','lta','label','LTA','type','reimbursement','monthly_exact',v_lta,'monthly_display',round(v_lta),'annual_exact',v_lta*v_months),
    jsonb_build_object('key','employer_pf','label','Employer PF Contribution','type','employer_contribution','monthly_exact',v_employer_pf,'monthly_display',round(v_employer_pf),'annual_exact',v_employer_pf*v_months),
    jsonb_build_object('key','employer_benefit','label','ESIC / Mediclaim','type','employer_contribution','monthly_exact',v_employer_benefit,'monthly_display',round(v_employer_benefit),'annual_exact',v_employer_benefit*v_months),
    jsonb_build_object('key','employee_pf','label','Employee PF Deduction','type','deduction','monthly_exact',v_employer_pf,'monthly_display',round(v_employer_pf),'annual_exact',v_employer_pf*v_months),
    jsonb_build_object('key','employee_esic','label','Employee ESIC Deduction','type','deduction','monthly_exact',v_employee_esic,'monthly_display',round(v_employee_esic),'annual_exact',v_employee_esic*v_months),
    jsonb_build_object('key','professional_tax','label','Professional Tax','type','deduction','monthly_exact',v_pt,'monthly_display',round(v_pt),'annual_exact',v_pt*v_months)
  );
  return jsonb_build_object('components',v_components,'monthly_gross',v_gross,'annual_gross',v_gross*v_months,
    'monthly_ctc',v_monthly_ctc,'annual_ctc',v_monthly_ctc*v_months,'monthly_deductions',v_deductions,
    'net_take_home',v_gross-v_deductions,'context',jsonb_build_object('grade',v_fit.grade,'designation_band',v_fit.designation_band));
end
$$;

revoke all on function public.calculate_ctc_structure_3(uuid,uuid,jsonb,date,text) from public,anon;
grant execute on function public.calculate_ctc_structure_3(uuid,uuid,jsonb,date,text) to authenticated;

commit;
