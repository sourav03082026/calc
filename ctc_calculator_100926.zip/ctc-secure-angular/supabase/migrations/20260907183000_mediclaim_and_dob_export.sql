begin;

update public.salary_structure_versions v
set declarations_schema = jsonb_set(
  v.declarations_schema,
  '{required}',
  case
    when (v.declarations_schema->'required') ? 'mediclaim_annual' then v.declarations_schema->'required'
    else (v.declarations_schema->'required') || '"mediclaim_annual"'::jsonb
  end
)
where exists (
  select 1 from public.salary_structures s
  where s.id = v.structure_id and s.code in ('STRUCTURE_1','STRUCTURE_2')
);

create or replace view public.finalized_ctc_export with (security_invoker=true) as
select s.id snapshot_id,s.organization_id,s.finalized_at,s.candidate_snapshot->>'candidate_name' candidate_name,
 s.candidate_snapshot->>'company' company,s.candidate_snapshot->>'grade' grade,
 s.candidate_snapshot->>'designation' designation,s.candidate_snapshot->>'department' department,
 (s.candidate_snapshot->>'date_of_joining')::date date_of_joining,
 s.result_snapshot->'components' components,(s.result_snapshot->>'monthly_gross')::numeric monthly_gross,
 (s.result_snapshot->>'monthly_ctc')::numeric monthly_ctc,(s.result_snapshot->>'net_take_home')::numeric net_take_home,
 (s.result_snapshot->>'annual_ctc')::numeric annual_ctc,
 (s.candidate_snapshot->>'date_of_birth')::date date_of_birth
from public.ctc_snapshots s;

grant select on public.finalized_ctc_export to authenticated;

commit;
