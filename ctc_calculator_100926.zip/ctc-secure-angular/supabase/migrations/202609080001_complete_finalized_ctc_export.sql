begin;

drop view if exists public.finalized_ctc_export;

create view public.finalized_ctc_export with (security_invoker=true) as
select
  s.id snapshot_id,
  s.organization_id,
  s.finalized_at,
  c.offer_reference,
  st.code structure_code,
  st.name structure_name,
  s.candidate_snapshot->>'candidate_name' candidate_name,
  s.candidate_snapshot->>'date_of_birth' date_of_birth,
  s.candidate_snapshot->>'company' company,
  s.candidate_snapshot->>'grade' grade,
  s.candidate_snapshot->>'qualification' qualification,
  nullif(s.candidate_snapshot->>'experience_months','')::integer experience_months,
  s.candidate_snapshot->>'designation' designation,
  s.candidate_snapshot->>'department' department,
  (s.candidate_snapshot->>'date_of_joining')::date date_of_joining,
  s.result_snapshot->'components' components,
  (s.result_snapshot->>'monthly_gross')::numeric monthly_gross,
  (s.result_snapshot->>'monthly_ctc')::numeric monthly_ctc,
  (s.result_snapshot->>'net_take_home')::numeric net_take_home,
  (s.result_snapshot->>'annual_ctc')::numeric annual_ctc
from public.ctc_snapshots s
join public.ctc_cases c on c.id=s.case_id
join public.salary_structure_versions sv on sv.id=c.structure_version_id
join public.salary_structures st on st.id=sv.structure_id;

grant select on public.finalized_ctc_export to authenticated;

commit;
