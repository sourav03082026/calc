begin;

revoke update on public.ctc_cases from authenticated;

create or replace function public.save_ctc_draft(p_case_id uuid,p_expected_version integer,p_inputs jsonb)
returns public.ctc_cases language plpgsql security definer set search_path='' as $$
declare v_case public.ctc_cases;
begin
  select * into v_case from public.ctc_cases where id=p_case_id and status='draft';
  if v_case.id is null or not private.can_access_owned_record(v_case.organization_id,v_case.owner_user_id,null) then raise exception 'Access denied'; end if;
  update public.ctc_cases set inputs=p_inputs,calculated_result=null,version=version+1,updated_at=now()
  where id=p_case_id and status='draft' and version=p_expected_version returning * into v_case;
  if v_case.id is null then raise exception 'Draft changed or is no longer editable'; end if;
  return v_case;
end $$;

create or replace function public.recalculate_ctc_case(p_case_id uuid,p_expected_version integer)
returns public.ctc_cases language plpgsql security definer set search_path='' as $$
declare v_case public.ctc_cases; v_candidate public.candidates; v_result jsonb;
begin
  select * into v_case from public.ctc_cases where id=p_case_id and status='draft';
  if v_case.id is null or not private.can_access_owned_record(v_case.organization_id,v_case.owner_user_id,null) then raise exception 'Access denied'; end if;
  if v_case.version<>p_expected_version then raise exception 'Draft changed or cannot be calculated'; end if;
  select * into v_candidate from public.candidates where id=v_case.candidate_id;
  v_result:=public.calculate_ctc(v_case.organization_id,v_case.structure_version_id,v_case.inputs,coalesce(v_candidate.date_of_joining,current_date),v_candidate.state_code);
  update public.ctc_cases set calculated_result=v_result,version=version+1,updated_at=now()
  where id=v_case.id and version=p_expected_version returning * into v_case;
  if v_case.id is null then raise exception 'Concurrent draft update detected'; end if;
  return v_case;
end $$;

create or replace function public.finalize_ctc_case(p_case_id uuid,p_expected_version integer,p_idempotency_key text)
returns uuid language plpgsql security definer set search_path='' as $$
declare v_case public.ctc_cases; v_candidate public.candidates; v_snapshot uuid; v_rules jsonb; v_structure jsonb; v_revision integer;
begin
  select * into v_case from public.ctc_cases where id=p_case_id for update;
  if v_case.id is null or not private.can_access_owned_record(v_case.organization_id,v_case.owner_user_id,null) then raise exception 'Access denied'; end if;
  if v_case.status<>'draft' or v_case.version<>p_expected_version then raise exception 'Draft changed or cannot be finalized'; end if;
  if v_case.calculated_result is null then raise exception 'A verified server calculation is required'; end if;
  if abs((v_case.calculated_result->>'monthly_ctc')::numeric-(v_case.inputs->>'monthly_ctc')::numeric)>=0.01 then raise exception 'CTC reconciliation failed'; end if;
  select * into v_candidate from public.candidates where id=v_case.candidate_id;
  if v_candidate.id is null then raise exception 'Candidate not found'; end if;
  select coalesce(max(revision),0)+1 into v_revision from public.ctc_snapshots where case_id=p_case_id;
  select to_jsonb(r) into v_rules from public.statutory_rule_sets r where r.active and r.effective_from<=coalesce(v_candidate.date_of_joining,current_date) and (r.effective_to is null or r.effective_to>=coalesce(v_candidate.date_of_joining,current_date)) and (r.organization_id=v_case.organization_id or r.organization_id is null) and (r.state_code=v_candidate.state_code or r.state_code is null) order by (r.organization_id is not null) desc,(r.state_code is not null) desc,r.effective_from desc limit 1;
  select jsonb_build_object('version',to_jsonb(v),'structure',to_jsonb(s),'components',coalesce(jsonb_agg(to_jsonb(c) order by c.sequence),'[]'::jsonb)) into v_structure
    from public.salary_structure_versions v join public.salary_structures s on s.id=v.structure_id left join public.salary_components c on c.structure_version_id=v.id where v.id=v_case.structure_version_id group by v.id,s.id;
  insert into public.ctc_snapshots(organization_id,case_id,revision,candidate_snapshot,input_snapshot,rules_snapshot,result_snapshot,structure_snapshot,finalized_by)
  values(v_case.organization_id,v_case.id,v_revision,to_jsonb(v_candidate),v_case.inputs,coalesce(v_rules,'{}'::jsonb),v_case.calculated_result,v_structure,(select auth.uid())) returning id into v_snapshot;
  update public.ctc_cases set status='finalized',finalized_at=now(),finalized_by=(select auth.uid()),version=version+1,updated_at=now() where id=v_case.id;
  insert into public.document_jobs(organization_id,snapshot_id,requested_by,idempotency_key) values(v_case.organization_id,v_snapshot,(select auth.uid()),p_idempotency_key);
  insert into public.audit_events(organization_id,actor_user_id,event_type,entity_type,entity_id,metadata) values(v_case.organization_id,(select auth.uid()),'ctc.finalized','ctc_snapshot',v_snapshot,jsonb_build_object('case_id',v_case.id,'revision',v_revision));
  return v_snapshot;
end $$;

revoke all on function public.save_ctc_draft(uuid,integer,jsonb),public.recalculate_ctc_case(uuid,integer),public.finalize_ctc_case(uuid,integer,text) from public,anon;
grant execute on function public.save_ctc_draft(uuid,integer,jsonb),public.recalculate_ctc_case(uuid,integer),public.finalize_ctc_case(uuid,integer,text) to authenticated;

create table public.document_download_grants(
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  document_id uuid not null references public.secure_documents(id) on delete cascade,
  requested_by uuid not null references auth.users(id),
  token_hash text not null unique,
  expires_at timestamptz not null,
  consumed_at timestamptz,
  created_at timestamptz not null default now()
);
alter table public.document_download_grants enable row level security;
revoke all on public.document_download_grants from anon,authenticated;

do $$
begin
  if not exists(select 1 from vault.secrets where name='document_kek_v1') then
    perform vault.create_secret(encode(extensions.gen_random_bytes(32),'base64'),'document_kek_v1','Application-level offer-document key-encryption key');
  end if;
end $$;

create or replace function public.wrap_document_key(p_plain_key text)
returns text language sql volatile security definer set search_path='' as $$
  select encode(extensions.pgp_sym_encrypt(p_plain_key,(select decrypted_secret from vault.decrypted_secrets where name='document_kek_v1'),'cipher-algo=aes256'),'base64')
$$;
create or replace function public.unwrap_document_key(p_wrapped_key text)
returns text language sql volatile security definer set search_path='' as $$
  select extensions.pgp_sym_decrypt(decode(p_wrapped_key,'base64'),(select decrypted_secret from vault.decrypted_secrets where name='document_kek_v1'))
$$;
revoke all on function public.wrap_document_key(text),public.unwrap_document_key(text) from public,anon,authenticated;
grant execute on function public.wrap_document_key(text),public.unwrap_document_key(text) to service_role;

create or replace function public.assign_organization_role(p_organization_id uuid,p_email text,p_role public.app_role)
returns void language plpgsql security definer set search_path='' as $$
declare v_target uuid;
begin
  if not private.has_org_role(p_organization_id,array['organization_admin']::public.app_role[]) then raise exception 'Access denied'; end if;
  select id into v_target from auth.users where lower(email)=lower(trim(p_email));
  if v_target is null then raise exception 'User must accept the Supabase invitation before role assignment'; end if;
  insert into public.organization_members(organization_id,user_id,role,created_by)
  values(p_organization_id,v_target,p_role,(select auth.uid()))
  on conflict(organization_id,user_id) do update set role=excluded.role,active=true;
  insert into public.audit_events(organization_id,actor_user_id,event_type,entity_type,entity_id,metadata)
  values(p_organization_id,(select auth.uid()),'member.role_assigned','user',v_target,jsonb_build_object('role',p_role,'email_hash',encode(extensions.digest(lower(trim(p_email)),'sha256'),'hex')));
end $$;
revoke all on function public.assign_organization_role(uuid,text,public.app_role) from public,anon;
grant execute on function public.assign_organization_role(uuid,text,public.app_role) to authenticated;

commit;
