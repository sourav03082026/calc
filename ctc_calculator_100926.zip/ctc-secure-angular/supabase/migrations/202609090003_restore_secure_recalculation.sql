begin;

-- Structure 3 introduced dispatching but unintentionally downgraded this
-- protected write path to SECURITY INVOKER. Direct table UPDATE remains
-- revoked; this function performs the authorized, version-checked mutation.
create or replace function public.recalculate_ctc_case(
  p_case_id uuid,
  p_expected_version integer
)
returns public.ctc_cases
language plpgsql
security definer
set search_path=''
as $$
declare
  v_case public.ctc_cases;
  v_candidate public.candidates;
  v_result jsonb;
  v_code text;
begin
  select * into v_case
  from public.ctc_cases
  where id=p_case_id and status='draft';

  if v_case.id is null
     or not private.can_access_owned_record(
       v_case.organization_id,
       v_case.owner_user_id,
       null
     ) then
    raise exception 'Access denied';
  end if;

  if v_case.version<>p_expected_version then
    raise exception 'Draft changed or cannot be calculated';
  end if;

  select * into v_candidate
  from public.candidates
  where id=v_case.candidate_id;

  if v_candidate.id is null then
    raise exception 'Candidate not found';
  end if;

  select s.code into v_code
  from public.salary_structure_versions v
  join public.salary_structures s on s.id=v.structure_id
  where v.id=v_case.structure_version_id;

  if v_code='STRUCTURE_3' then
    v_result:=public.calculate_ctc_structure_3(
      v_case.organization_id,
      v_case.structure_version_id,
      v_case.inputs,
      coalesce(v_candidate.date_of_joining,current_date),
      v_candidate.state_code
    );
  else
    v_result:=public.calculate_ctc(
      v_case.organization_id,
      v_case.structure_version_id,
      v_case.inputs,
      coalesce(v_candidate.date_of_joining,current_date),
      v_candidate.state_code
    );
  end if;

  update public.ctc_cases
  set calculated_result=v_result,
      version=version+1,
      updated_at=now()
  where id=v_case.id
    and status='draft'
    and version=p_expected_version
  returning * into v_case;

  if v_case.id is null then
    raise exception 'Concurrent draft update detected';
  end if;

  return v_case;
end
$$;

revoke all on function public.recalculate_ctc_case(uuid,integer)
from public,anon;
grant execute on function public.recalculate_ctc_case(uuid,integer)
to authenticated;

commit;
