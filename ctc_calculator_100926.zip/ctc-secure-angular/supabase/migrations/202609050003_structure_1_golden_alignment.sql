begin;

update public.salary_components c
set expression='{"op":"if_eq","key":"benefit_mode","value":"ESIC","then":{"op":"div","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"input","key":"monthly_ctc"},{"op":"ref","key":"basic_salary"}]},{"op":"ref","key":"hra"}]},{"op":"ref","key":"annual_bonus"}]},{"op":"ref","key":"advance_bonus"}]},{"op":"mul","args":[{"op":"param","key":"pf_rate"},{"op":"ref","key":"basic_salary"}]}]},{"op":"mul","args":[{"op":"param","key":"esic_employer_rate"},{"op":"add","args":[{"op":"ref","key":"basic_salary"},{"op":"ref","key":"hra"},{"op":"ref","key":"advance_bonus"}]}]}]},{"op":"add","args":[{"op":"const","value":1},{"op":"param","key":"pf_rate"},{"op":"param","key":"esic_employer_rate"}]}]},"else":{"op":"div","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"input","key":"monthly_ctc"},{"op":"ref","key":"basic_salary"}]},{"op":"ref","key":"hra"}]},{"op":"ref","key":"annual_bonus"}]},{"op":"ref","key":"advance_bonus"}]},{"op":"div","args":[{"op":"param","key":"mediclaim_annual"},{"op":"param","key":"months_per_year"}]}]},{"op":"mul","args":[{"op":"param","key":"pf_rate"},{"op":"ref","key":"basic_salary"}]}]},{"op":"add","args":[{"op":"const","value":1},{"op":"param","key":"pf_rate"}]}]}}'::jsonb
where c.component_key='special_allowance' and exists(
 select 1 from public.salary_structure_versions v join public.salary_structures s on s.id=v.structure_id
 where v.id=c.structure_version_id and s.code='STRUCTURE_1' and v.version_no=1
);

commit;
