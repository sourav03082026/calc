begin;

-- Privileged implementations live outside the exposed API schema. Each operation
-- independently validates the authenticated user, active membership, ownership,
-- lifecycle state and optimistic version before changing any data.
create or replace function private.delete_own_ctc_draft(
  p_case_id uuid,
  p_expected_version integer
) returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_actor uuid := (select auth.uid());
  v_case public.ctc_cases;
begin
  if v_actor is null then raise exception 'Authentication required'; end if;

  select * into v_case
  from public.ctc_cases
  where id = p_case_id
  for update;

  if v_case.id is null then raise exception 'CTC draft not found'; end if;
  if v_case.owner_user_id <> v_actor then raise exception 'Access denied: only the creating recruiter can delete this CTC'; end if;
  if v_case.status <> 'draft' then raise exception 'Only a draft CTC can be deleted'; end if;
  if v_case.version <> p_expected_version then raise exception 'Draft changed. Refresh before deleting'; end if;
  if not exists (
    select 1 from public.organization_members m
    where m.organization_id = v_case.organization_id
      and m.user_id = v_actor and m.active
      and m.role in ('recruiter','organization_admin')
  ) then raise exception 'Active recruiter access required'; end if;

  insert into public.audit_events(organization_id,actor_user_id,event_type,entity_type,entity_id,metadata)
  values(v_case.organization_id,v_actor,'ctc_draft_deleted','ctc_case',v_case.id,
    jsonb_build_object('candidate_id',v_case.candidate_id,'offer_reference',v_case.offer_reference,'version',v_case.version));

  delete from public.ctc_cases where id = v_case.id;
  delete from public.candidates c
  where c.id = v_case.candidate_id and c.owner_user_id = v_actor
    and not exists(select 1 from public.ctc_cases x where x.candidate_id = c.id);
end $$;

create or replace function private.cancel_own_finalized_ctc(
  p_case_id uuid,
  p_expected_version integer
) returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_actor uuid := (select auth.uid());
  v_case public.ctc_cases;
begin
  if v_actor is null then raise exception 'Authentication required'; end if;

  select * into v_case
  from public.ctc_cases
  where id = p_case_id
  for update;

  if v_case.id is null then raise exception 'Finalized CTC not found'; end if;
  if v_case.owner_user_id <> v_actor then raise exception 'Access denied: only the creating recruiter can cancel this CTC'; end if;
  if v_case.status <> 'finalized' then raise exception 'Only a finalized CTC can be cancelled'; end if;
  if v_case.version <> p_expected_version then raise exception 'CTC changed. Refresh before cancelling'; end if;
  if not exists (
    select 1 from public.organization_members m
    where m.organization_id = v_case.organization_id
      and m.user_id = v_actor and m.active
      and m.role in ('recruiter','organization_admin')
  ) then raise exception 'Active recruiter access required'; end if;

  update public.ctc_cases
  set status='cancelled',version=version+1,updated_at=now()
  where id=v_case.id and version=p_expected_version;
  if not found then raise exception 'Concurrent CTC update detected'; end if;

  insert into public.audit_events(organization_id,actor_user_id,event_type,entity_type,entity_id,metadata)
  values(v_case.organization_id,v_actor,'finalized_ctc_cancelled','ctc_case',v_case.id,
    jsonb_build_object('offer_reference',v_case.offer_reference,'finalized_at',v_case.finalized_at));
end $$;

revoke all on function private.delete_own_ctc_draft(uuid,integer) from public,anon,authenticated;
revoke all on function private.cancel_own_finalized_ctc(uuid,integer) from public,anon,authenticated;
grant execute on function private.delete_own_ctc_draft(uuid,integer) to authenticated;
grant execute on function private.cancel_own_finalized_ctc(uuid,integer) to authenticated;

create or replace function public.delete_own_ctc_draft(p_case_id uuid,p_expected_version integer)
returns void language sql security invoker set search_path='' as $$
  select private.delete_own_ctc_draft(p_case_id,p_expected_version)
$$;

create or replace function public.cancel_own_finalized_ctc(p_case_id uuid,p_expected_version integer)
returns void language sql security invoker set search_path='' as $$
  select private.cancel_own_finalized_ctc(p_case_id,p_expected_version)
$$;

revoke all on function public.delete_own_ctc_draft(uuid,integer) from public,anon;
revoke all on function public.cancel_own_finalized_ctc(uuid,integer) from public,anon;
grant execute on function public.delete_own_ctc_draft(uuid,integer) to authenticated;
grant execute on function public.cancel_own_finalized_ctc(uuid,integer) to authenticated;

commit;
