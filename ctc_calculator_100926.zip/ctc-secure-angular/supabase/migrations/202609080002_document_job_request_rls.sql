begin;

drop policy if exists jobs_insert_accessible_snapshot on public.document_jobs;
create policy jobs_insert_accessible_snapshot
on public.document_jobs
for insert
to authenticated
with check (
  requested_by = (select auth.uid())
  and exists (
    select 1
    from public.ctc_snapshots s
    join public.ctc_cases c on c.id = s.case_id
    where s.id = document_jobs.snapshot_id
      and s.organization_id = document_jobs.organization_id
      and private.can_access_owned_record(c.organization_id, c.owner_user_id, null)
  )
  and (
    template_id is null
    or exists (
      select 1
      from public.offer_templates t
      where t.id = document_jobs.template_id
        and t.organization_id = document_jobs.organization_id
    )
  )
);

create or replace function public.request_document_job(
  p_snapshot_id uuid,
  p_template_id uuid,
  p_idempotency_key text
)
returns uuid
language plpgsql
security invoker
set search_path=''
as $$
declare
  v_snapshot public.ctc_snapshots;
  v_case public.ctc_cases;
  v_job uuid;
begin
  select * into v_snapshot from public.ctc_snapshots where id=p_snapshot_id;
  select * into v_case from public.ctc_cases where id=v_snapshot.case_id;
  if v_snapshot.id is null or not private.can_access_owned_record(v_snapshot.organization_id,v_case.owner_user_id,null) then
    raise exception 'Access denied';
  end if;

  insert into public.document_jobs(
    organization_id,snapshot_id,template_id,requested_by,idempotency_key
  )
  values(
    v_snapshot.organization_id,p_snapshot_id,p_template_id,(select auth.uid()),p_idempotency_key
  )
  on conflict(organization_id,idempotency_key) do nothing
  returning id into v_job;

  if v_job is null then
    select id into v_job
    from public.document_jobs
    where organization_id=v_snapshot.organization_id
      and idempotency_key=p_idempotency_key;
  end if;

  return v_job;
end
$$;

revoke all on function public.request_document_job(uuid,uuid,text) from public,anon;
grant execute on function public.request_document_job(uuid,uuid,text) to authenticated;

commit;
