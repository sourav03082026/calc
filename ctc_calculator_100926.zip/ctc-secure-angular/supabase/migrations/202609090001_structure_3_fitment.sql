begin;

-- Structure 3 is intentionally isolated from the calculation graphs for Structures 1 and 2.
create table public.structure_3_fitment_rules (
  id uuid primary key default gen_random_uuid(),
  grade text not null,
  designation_band text not null,
  communication_monthly numeric(18,6) not null default 0,
  conveyance_monthly numeric(18,6) not null default 0,
  books_monthly numeric(18,6) not null default 0,
  attire_monthly numeric(18,6) not null default 0,
  entertainment_annual numeric(18,6) not null default 0,
  meal_card_monthly numeric(18,6) not null default 0,
  lta_eligible boolean not null default false,
  active boolean not null default true,
  unique (grade)
);

alter table public.structure_3_fitment_rules enable row level security;
create policy structure_3_fitment_read on public.structure_3_fitment_rules
  for select to authenticated using (true);
grant select on public.structure_3_fitment_rules to authenticated;

insert into public.structure_3_fitment_rules
  (grade,designation_band,communication_monthly,conveyance_monthly,books_monthly,attire_monthly,entertainment_annual,meal_card_monthly,lta_eligible)
values
 ('L20','JOINT VICE PRESIDENT and ABOVE',10000,90000,3000,2500,300000,8800,true),
 ('L19','Sr. VICE PRESIDENT',9000,80000,3000,2500,300000,8800,true),
 ('L18','VICE PRESIDENT',8000,75000,3000,2500,300000,8800,true),
 ('L17','ASSOCIATE VICE PRESIDENT',6000,60000,3000,2500,200000,8800,true),
 ('L16','SR. GENERAL MANAGER',5000,55000,2500,2500,200000,8800,true),
 ('L15','GENERAL MANAGER',5000,50000,2000,2500,150000,8800,true),
 ('L14','DGM',4000,45000,1500,2500,100000,8800,true),
 ('L13','AGM',4000,40000,1500,2000,50000,8800,true),
 ('L12','SR. MANAGER',2000,30000,1000,2000,0,8800,true),
 ('L11','MANAGER',2000,25000,1000,2000,0,8800,false),
 ('L10','ASST. MANAGER / DEPUTY MANAGER',1000,20000,1000,2000,0,8800,false),
 ('L9','ASST. MANAGER / DEPUTY MANAGER',1000,20000,1000,2000,0,8800,false),
 ('L8','SENIOR EXECUTIVE',0,0,0,1000,0,0,false),
 ('L7','BELOW SENIOR EXECUTIVE',0,0,0,0,0,0,false),
 ('L6','BELOW SENIOR EXECUTIVE',0,0,0,0,0,0,false),
 ('L5','BELOW SENIOR EXECUTIVE',0,0,0,0,0,0,false),
 ('L4','BELOW SENIOR EXECUTIVE',0,0,0,0,0,0,false),
 ('L3','BELOW SENIOR EXECUTIVE',0,0,0,0,0,0,false),
 ('L2','BELOW SENIOR EXECUTIVE',0,0,0,0,0,0,false),
 ('L1','BELOW SENIOR EXECUTIVE',0,0,0,0,0,0,false);

with st as (
  insert into public.salary_structures(organization_id,code,name,description)
  values(null,'STRUCTURE_3','Structure 3','Grade-based tax-efficient fitment with Monthly Allowance as the final balancer')
  returning id
)
insert into public.salary_structure_versions(structure_id,version_no,effective_from,parameters,declarations_schema,source_hash)
select id,1,'2026-01-01','{}'::jsonb,
 '{"required":["monthly_ctc","grade","benefit_mode","bonus_mode","pf_basis","mediclaim_annual"],"enums":{"benefit_mode":["MEDICLAIM","ESIC"],"bonus_mode":["ANNUAL","OFF"],"pf_basis":["CAPPED","ACTUAL_WAGES"]}}'::jsonb,
 '56cc2f9fe30066c1475451c7ce860ed6e8db9f32f69987f065f94094ef636cad' from st;

create or replace function public.calculate_ctc_structure_3(
  p_organization_id uuid,p_structure_version_id uuid,p_inputs jsonb,p_effective_date date,p_state_code text
) returns jsonb language plpgsql stable security invoker set search_path='' as $$
declare
  v_structure_code text; v_fit public.structure_3_fitment_rules; v_rules jsonb;
  v_months numeric; v_monthly_ctc numeric; v_basic numeric; v_hra numeric;
  v_attire numeric; v_communication numeric; v_conveyance numeric; v_books numeric;
  v_entertainment numeric; v_meal numeric; v_lta numeric; v_bonus numeric;
  v_pf_wages numeric; v_employer_pf numeric; v_employer_benefit numeric;
  v_allowance numeric; v_gross numeric; v_employee_esic numeric; v_pt numeric;
  v_deductions numeric; v_components jsonb := '[]'::jsonb;
begin
  if not private.has_org_role(p_organization_id,array['organization_admin','recruiter','payroll_administrator','chro']::public.app_role[])
    then raise exception 'Access denied'; end if;
  select s.code into v_structure_code from public.salary_structure_versions v
    join public.salary_structures s on s.id=v.structure_id
    where v.id=p_structure_version_id and v.active and v.effective_from<=p_effective_date
      and (v.effective_to is null or v.effective_to>=p_effective_date);
  if v_structure_code is distinct from 'STRUCTURE_3' then raise exception 'Invalid Structure 3 version'; end if;
  select * into v_fit from public.structure_3_fitment_rules
    where grade=upper(trim(p_inputs->>'grade')) and active;
  if v_fit.id is null then raise exception 'Select a valid Structure 3 grade (L1 to L20)'; end if;
  select coalesce(r.settings,'{}'::jsonb) into v_rules from public.statutory_rule_sets r
    where r.active and r.effective_from<=p_effective_date and (r.effective_to is null or r.effective_to>=p_effective_date)
      and (r.organization_id=p_organization_id or r.organization_id is null)
      and (r.state_code=p_state_code or r.state_code is null)
    order by (r.organization_id is not null) desc,(r.state_code is not null) desc,r.effective_from desc limit 1;
  v_months := (v_rules->>'months_per_year')::numeric;
  v_monthly_ctc := (p_inputs->>'monthly_ctc')::numeric;
  if v_monthly_ctc < (v_rules->>'minimum_monthly_ctc')::numeric then raise exception 'Monthly CTC is below the configured minimum'; end if;
  v_basic := v_monthly_ctc * (v_rules->>'basic_pct')::numeric;
  v_hra := v_basic * (v_rules->>'hra_pct')::numeric;
  v_attire := case when coalesce((p_inputs->>'opt_attire')::boolean,false) then v_fit.attire_monthly else 0 end;
  v_communication := case when coalesce((p_inputs->>'opt_communication')::boolean,false) then v_fit.communication_monthly else 0 end;
  v_conveyance := case when coalesce((p_inputs->>'opt_conveyance')::boolean,false) then v_fit.conveyance_monthly else 0 end;
  v_books := case when coalesce((p_inputs->>'opt_books')::boolean,false) then v_fit.books_monthly else 0 end;
  v_entertainment := case when coalesce((p_inputs->>'opt_entertainment')::boolean,false) then v_fit.entertainment_annual/v_months else 0 end;
  v_meal := case when coalesce((p_inputs->>'opt_meal_card')::boolean,false) then v_fit.meal_card_monthly else 0 end;
  v_lta := case when coalesce((p_inputs->>'opt_lta')::boolean,false) and v_fit.lta_eligible then v_basic/v_months else 0 end;
  v_bonus := case when p_inputs->>'bonus_mode'='ANNUAL' then v_basic/v_months else 0 end;
  v_pf_wages := case when p_inputs->>'pf_basis'='ACTUAL_WAGES' then v_basic else least((v_rules->>'pf_wage_cap')::numeric,v_basic) end;
  v_employer_pf := v_pf_wages * (v_rules->>'pf_rate')::numeric;

  -- ESIC is solved algebraically because its employer share is part of CTC and depends on payroll gross.
  if p_inputs->>'benefit_mode'='ESIC' then
    v_allowance := (v_monthly_ctc-v_basic-v_hra-v_attire-v_communication-v_conveyance-v_books-v_entertainment-v_meal-v_lta-v_bonus-v_employer_pf
      -(v_rules->>'esic_employer_rate')::numeric*(v_basic+v_hra+v_attire))/(1+(v_rules->>'esic_employer_rate')::numeric);
    v_gross := v_basic+v_hra+v_attire+v_allowance;
    v_employer_benefit := v_gross*(v_rules->>'esic_employer_rate')::numeric;
    v_employee_esic := v_gross*(v_rules->>'esic_employee_rate')::numeric;
  else
    v_employer_benefit := (p_inputs->>'mediclaim_annual')::numeric/v_months;
    v_employee_esic := 0;
    v_allowance := v_monthly_ctc-v_basic-v_hra-v_attire-v_communication-v_conveyance-v_books-v_entertainment-v_meal-v_lta-v_bonus-v_employer_pf-v_employer_benefit;
    v_gross := v_basic+v_hra+v_attire+v_allowance;
  end if;
  if v_allowance < 0 then raise exception 'Selected benefits exceed available CTC. Deselect one or more optional heads.'; end if;
  v_pt := private.professional_tax(p_organization_id,p_state_code,p_effective_date,v_gross);
  v_deductions := v_employer_pf+v_employee_esic+v_pt;

  v_components := jsonb_build_array(
    jsonb_build_object('key','basic_salary','label','Basic Salary','type','earning','monthly_exact',v_basic,'monthly_display',round(v_basic),'annual_exact',v_basic*v_months),
    jsonb_build_object('key','hra','label','HRA','type','earning','monthly_exact',v_hra,'monthly_display',round(v_hra),'annual_exact',v_hra*v_months),
    jsonb_build_object('key','attire_allowance','label','Attire & Uniform Allowance','type','earning','monthly_exact',v_attire,'monthly_display',round(v_attire),'annual_exact',v_attire*v_months),
    jsonb_build_object('key','monthly_allowance','label','Monthly Allowance','type','earning','monthly_exact',v_allowance,'monthly_display',round(v_allowance),'annual_exact',v_allowance*v_months),
    jsonb_build_object('key','communication_reimbursement','label','Communication Reimbursement','type','reimbursement','monthly_exact',v_communication,'monthly_display',round(v_communication),'annual_exact',v_communication*v_months),
    jsonb_build_object('key','conveyance_reimbursement','label','Conveyance Reimbursement','type','reimbursement','monthly_exact',v_conveyance,'monthly_display',round(v_conveyance),'annual_exact',v_conveyance*v_months),
    jsonb_build_object('key','books_periodicals','label','Books & Periodicals','type','reimbursement','monthly_exact',v_books,'monthly_display',round(v_books),'annual_exact',v_books*v_months),
    jsonb_build_object('key','entertainment_allowance','label','Entertainment Allowance','type','reimbursement','monthly_exact',v_entertainment,'monthly_display',round(v_entertainment),'annual_exact',v_entertainment*v_months),
    jsonb_build_object('key','meal_card','label','Meal Card','type','reimbursement','monthly_exact',v_meal,'monthly_display',round(v_meal),'annual_exact',v_meal*v_months),
    jsonb_build_object('key','annual_bonus','label','Annual Bonus','type','annual_benefit','monthly_exact',v_bonus,'monthly_display',round(v_bonus),'annual_exact',v_bonus*v_months),
    jsonb_build_object('key','lta','label','LTA','type','reimbursement','monthly_exact',v_lta,'monthly_display',round(v_lta),'annual_exact',v_lta*v_months),
    jsonb_build_object('key','employer_pf','label','Employer PF Contribution','type','employer_contribution','monthly_exact',v_employer_pf,'monthly_display',round(v_employer_pf),'annual_exact',v_employer_pf*v_months),
    jsonb_build_object('key','employer_benefit','label','ESIC / Mediclaim','type','employer_contribution','monthly_exact',v_employer_benefit,'monthly_display',round(v_employer_benefit),'annual_exact',v_employer_benefit*v_months),
    jsonb_build_object('key','employee_pf','label','Employee PF Deduction','type','deduction','monthly_exact',v_employer_pf,'monthly_display',round(v_employer_pf),'annual_exact',v_employer_pf*v_months),
    jsonb_build_object('key','employee_esic','label','Employee ESIC Deduction','type','deduction','monthly_exact',v_employee_esic,'monthly_display',round(v_employee_esic),'annual_exact',v_employee_esic*v_months),
    jsonb_build_object('key','professional_tax','label','Professional Tax','type','deduction','monthly_exact',v_pt,'monthly_display',round(v_pt),'annual_exact',v_pt*v_months)
  );
  return jsonb_build_object('components',v_components,'monthly_gross',v_gross,'annual_gross',v_gross*v_months,
    'monthly_ctc',v_monthly_ctc,'annual_ctc',v_monthly_ctc*v_months,'monthly_deductions',v_deductions,
    'net_take_home',v_gross-v_deductions,'context',jsonb_build_object('grade',v_fit.grade,'designation_band',v_fit.designation_band));
end $$;

grant execute on function public.calculate_ctc_structure_3(uuid,uuid,jsonb,date,text) to authenticated;
revoke all on function public.calculate_ctc_structure_3(uuid,uuid,jsonb,date,text) from public,anon;

-- Dispatch only Structure 3 to its isolated calculator; existing Structure 1/2 calculation remains unchanged.
create or replace function public.recalculate_ctc_case(p_case_id uuid,p_expected_version integer)
returns public.ctc_cases language plpgsql security invoker set search_path='' as $$
declare v_case public.ctc_cases; v_candidate public.candidates; v_result jsonb; v_code text;
begin
  select * into v_case from public.ctc_cases where id=p_case_id and status='draft';
  if v_case.version<>p_expected_version then raise exception 'Draft changed or cannot be calculated'; end if;
  select * into v_candidate from public.candidates where id=v_case.candidate_id;
  select s.code into v_code from public.salary_structure_versions v join public.salary_structures s on s.id=v.structure_id where v.id=v_case.structure_version_id;
  if v_code='STRUCTURE_3' then
    v_result:=public.calculate_ctc_structure_3(v_case.organization_id,v_case.structure_version_id,v_case.inputs,coalesce(v_candidate.date_of_joining,current_date),v_candidate.state_code);
  else
    v_result:=public.calculate_ctc(v_case.organization_id,v_case.structure_version_id,v_case.inputs,coalesce(v_candidate.date_of_joining,current_date),v_candidate.state_code);
  end if;
  update public.ctc_cases set calculated_result=v_result,version=version+1,updated_at=now()
  where id=v_case.id and version=p_expected_version returning * into v_case;
  if v_case.id is null then raise exception 'Concurrent draft update detected'; end if;
  return v_case;
end $$;

grant execute on function public.recalculate_ctc_case(uuid,integer) to authenticated;
commit;
