begin;

with st as (
 insert into public.salary_structures(organization_id,code,name,description)
 values(null,'STRUCTURE_2','Structure 2','Monthly Allowance balancing mechanism from approved workbook') returning id
), sv as (
 insert into public.salary_structure_versions(structure_id,version_no,effective_from,parameters,declarations_schema,source_hash)
 select id,1,'2026-01-01','{}'::jsonb,
 '{"required":["monthly_ctc","minimum_wage_monthly","benefit_mode","bonus_mode","advance_bonus_opted","pf_basis","attire_annual"],"enums":{"benefit_mode":["MEDICLAIM","ESIC"],"bonus_mode":["ANNUAL","MONTHLY","OFF"],"advance_bonus_opted":["Y","N"],"pf_basis":["CAPPED","ACTUAL_WAGES"]}}'::jsonb,
 '2449679a7a403dca1ca99a6ef877f90454cbd3f8996de8be0c0edaa1f1b12bef' from st returning id
) insert into public.salary_components(structure_version_id,component_key,label,sequence,expression,component_type,include_in_gross,include_in_ctc,employee_deduction,visible)
select sv.id,x.component_key,x.label,x.sequence,x.expression::jsonb,x.component_type,x.in_gross,x.in_ctc,x.deduction,x.visible
from sv cross join (values
 ('basic_salary','Basic Salary',10,'{"op":"mul","args":[{"op":"input","key":"monthly_ctc"},{"op":"param","key":"basic_pct"}]}','earning',true,true,false,true),
 ('hra','HRA',20,'{"op":"mul","args":[{"op":"ref","key":"basic_salary"},{"op":"param","key":"hra_pct"}]}','earning',true,true,false,true),
 ('attire_allowance','Attire & Uniform Allowance',30,'{"op":"div","args":[{"op":"input","key":"attire_annual"},{"op":"param","key":"months_per_year"}]}','earning',true,true,false,true),
 ('annual_bonus','Annual Bonus',40,'{"op":"if_lte","left":{"op":"input","key":"monthly_ctc"},"right":{"op":"param","key":"bonus_eligibility_ceiling"},"then":{"op":"div","args":[{"op":"ref","key":"basic_salary"},{"op":"param","key":"months_per_year"}]},"else":{"op":"if_eq","key":"bonus_mode","value":"ANNUAL","then":{"op":"div","args":[{"op":"ref","key":"basic_salary"},{"op":"param","key":"months_per_year"}]},"else":{"op":"const","value":0}}}','earning',false,true,false,true),
 ('advance_bonus','Advance Bonus',50,'{"op":"if_eq","key":"bonus_mode","value":"MONTHLY","then":{"op":"div","args":[{"op":"ref","key":"basic_salary"},{"op":"param","key":"months_per_year"}]},"else":{"op":"if_eq","key":"advance_bonus_opted","value":"Y","then":{"op":"max","args":[{"op":"const","value":0},{"op":"sub","args":[{"op":"input","key":"minimum_wage_monthly"},{"op":"div","args":[{"op":"ref","key":"basic_salary"},{"op":"param","key":"months_per_year"}]}]}]},"else":{"op":"const","value":0}}}','earning',true,true,false,true),
 ('special_allowance','Special Allowance',60,'{"op":"if_gt","left":{"op":"sub","args":[{"op":"max","args":[{"op":"const","value":0},{"op":"sub","args":[{"op":"param","key":"pf_wage_cap"},{"op":"ref","key":"basic_salary"}]}]},{"op":"ref","key":"advance_bonus"}]},"right":{"op":"const","value":0},"then":{"op":"max","args":[{"op":"const","value":0},{"op":"sub","args":[{"op":"param","key":"pf_wage_cap"},{"op":"ref","key":"basic_salary"}]}]},"else":{"op":"const","value":0}}','earning',true,true,false,true),
 ('pf_wages','PF Wages',70,'{"op":"if_eq","key":"pf_basis","value":"ACTUAL_WAGES","then":{"op":"add","args":[{"op":"ref","key":"basic_salary"},{"op":"ref","key":"special_allowance"}]},"else":{"op":"min","args":[{"op":"param","key":"pf_wage_cap"},{"op":"add","args":[{"op":"ref","key":"basic_salary"},{"op":"ref","key":"special_allowance"}]}]}}','reference',false,false,false,true),
 ('employer_pf','Employer PF Contribution',80,'{"op":"mul","args":[{"op":"ref","key":"pf_wages"},{"op":"param","key":"pf_rate"}]}','employer_contribution',false,true,false,true),
 ('monthly_allowance','Monthly Allowance',90,'{"op":"if_eq","key":"benefit_mode","value":"ESIC","then":{"op":"div","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"input","key":"monthly_ctc"},{"op":"ref","key":"basic_salary"}]},{"op":"ref","key":"hra"}]},{"op":"ref","key":"attire_allowance"}]},{"op":"ref","key":"special_allowance"}]},{"op":"ref","key":"employer_pf"}]},{"op":"ref","key":"annual_bonus"}]},{"op":"ref","key":"advance_bonus"}]},{"op":"mul","args":[{"op":"param","key":"esic_employer_rate"},{"op":"add","args":[{"op":"ref","key":"basic_salary"},{"op":"ref","key":"hra"},{"op":"ref","key":"attire_allowance"},{"op":"ref","key":"special_allowance"},{"op":"ref","key":"advance_bonus"}]}]}]},{"op":"add","args":[{"op":"const","value":1},{"op":"param","key":"esic_employer_rate"}]}]},"else":{"op":"sub","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"sub","args":[{"op":"input","key":"monthly_ctc"},{"op":"ref","key":"basic_salary"}]},{"op":"ref","key":"hra"}]},{"op":"ref","key":"attire_allowance"}]},{"op":"ref","key":"special_allowance"}]},{"op":"ref","key":"employer_pf"}]},{"op":"ref","key":"annual_bonus"}]},{"op":"ref","key":"advance_bonus"}]},{"op":"div","args":[{"op":"param","key":"mediclaim_annual"},{"op":"param","key":"months_per_year"}]}]}}','earning',true,true,false,true),
 ('monthly_gross_base','Monthly Gross Base',100,'{"op":"add","args":[{"op":"ref","key":"basic_salary"},{"op":"ref","key":"hra"},{"op":"ref","key":"attire_allowance"},{"op":"ref","key":"special_allowance"},{"op":"ref","key":"monthly_allowance"},{"op":"ref","key":"advance_bonus"}]}','reference',false,false,false,false),
 ('employer_benefit','ESIC / Mediclaim',110,'{"op":"if_eq","key":"benefit_mode","value":"ESIC","then":{"op":"mul","args":[{"op":"ref","key":"monthly_gross_base"},{"op":"param","key":"esic_employer_rate"}]},"else":{"op":"div","args":[{"op":"param","key":"mediclaim_annual"},{"op":"param","key":"months_per_year"}]}}','employer_contribution',false,true,false,true),
 ('employee_pf','Employee PF Deduction',120,'{"op":"ref","key":"employer_pf"}','deduction',false,false,true,true),
 ('employee_esic','Employee ESIC Deduction',130,'{"op":"if_eq","key":"benefit_mode","value":"ESIC","then":{"op":"mul","args":[{"op":"ref","key":"monthly_gross_base"},{"op":"param","key":"esic_employee_rate"}]},"else":{"op":"const","value":0}}','deduction',false,false,true,true),
 ('professional_tax','Professional Tax',140,'{"op":"professional_tax","salary_ref":"monthly_gross_base"}','deduction',false,false,true,true)
) as x(component_key,label,sequence,expression,component_type,in_gross,in_ctc,deduction,visible);

-- Server-side calculation and persistence in a single authorized operation.
create or replace function public.recalculate_ctc_case(p_case_id uuid,p_expected_version integer)
returns public.ctc_cases language plpgsql security invoker set search_path='' as $$
declare v_case public.ctc_cases; v_candidate public.candidates; v_result jsonb;
begin
  select * into v_case from public.ctc_cases where id=p_case_id and status='draft';
  if v_case.id is null or v_case.version<>p_expected_version then raise exception 'Draft changed or cannot be calculated'; end if;
  select * into v_candidate from public.candidates where id=v_case.candidate_id;
  v_result:=public.calculate_ctc(v_case.organization_id,v_case.structure_version_id,v_case.inputs,coalesce(v_candidate.date_of_joining,current_date),v_candidate.state_code);
  update public.ctc_cases set calculated_result=v_result,version=version+1,updated_at=now()
  where id=v_case.id and version=p_expected_version returning * into v_case;
  if v_case.id is null then raise exception 'Concurrent draft update detected'; end if;
  return v_case;
end $$;

create or replace function public.request_document_job(p_snapshot_id uuid,p_template_id uuid,p_idempotency_key text)
returns uuid language plpgsql security invoker set search_path='' as $$
declare v_snapshot public.ctc_snapshots; v_case public.ctc_cases; v_job uuid;
begin
  select * into v_snapshot from public.ctc_snapshots where id=p_snapshot_id;
  select * into v_case from public.ctc_cases where id=v_snapshot.case_id;
  if v_snapshot.id is null or not private.can_access_owned_record(v_snapshot.organization_id,v_case.owner_user_id,null) then raise exception 'Access denied'; end if;
  insert into public.document_jobs(organization_id,snapshot_id,template_id,requested_by,idempotency_key)
  values(v_snapshot.organization_id,p_snapshot_id,p_template_id,(select auth.uid()),p_idempotency_key)
  on conflict(organization_id,idempotency_key) do update set idempotency_key=excluded.idempotency_key
  returning id into v_job;
  return v_job;
end $$;

grant execute on function public.recalculate_ctc_case(uuid,integer),public.request_document_job(uuid,uuid,text) to authenticated;

-- Privileged operational exports remain security-invoker views, so RLS still applies.
create view public.finalized_ctc_export with (security_invoker=true) as
select s.id snapshot_id,s.organization_id,s.finalized_at,s.candidate_snapshot->>'candidate_name' candidate_name,
 s.candidate_snapshot->>'company' company,s.candidate_snapshot->>'grade' grade,
 s.candidate_snapshot->>'designation' designation,s.candidate_snapshot->>'department' department,
 (s.candidate_snapshot->>'date_of_joining')::date date_of_joining,
 s.result_snapshot->'components' components,(s.result_snapshot->>'monthly_gross')::numeric monthly_gross,
 (s.result_snapshot->>'monthly_ctc')::numeric monthly_ctc,(s.result_snapshot->>'net_take_home')::numeric net_take_home,
 (s.result_snapshot->>'annual_ctc')::numeric annual_ctc
from public.ctc_snapshots s;
grant select on public.finalized_ctc_export to authenticated;

commit;
