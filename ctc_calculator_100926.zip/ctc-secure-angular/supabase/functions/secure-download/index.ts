import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const service = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });
const fromB64 = (s: string) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
async function sha256(value: string) { const bytes = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value)); return [...new Uint8Array(bytes)].map((x) => x.toString(16).padStart(2, "0")).join(""); }

Deno.serve(async (req: Request) => {
  try {
    const token = new URL(req.url).searchParams.get("token");
    if (!token) return new Response("Invalid link", { status: 400 });
    const hash = await sha256(token);
    const { data: grant } = await service.from("document_download_grants").select("*").eq("token_hash", hash).is("consumed_at", null).gt("expires_at", new Date().toISOString()).maybeSingle();
    if (!grant) return new Response("This download link is invalid or expired", { status: 403 });
    const consumed = await service.from("document_download_grants").update({ consumed_at: new Date().toISOString() }).eq("id", grant.id).is("consumed_at", null).select("id").maybeSingle();
    if (!consumed.data) return new Response("This download link has already been used", { status: 403 });
    const { data: doc, error } = await service.from("secure_documents").select("*").eq("id", grant.document_id).single();
    if (error) throw error;
    const stored = await service.storage.from("offer-documents").download(doc.storage_path); if (stored.error) throw stored.error;
    const { data: rawKey, error: unwrapError } = await service.rpc("unwrap_document_key", { p_wrapped_key: doc.encrypted_data_key }); if (unwrapError) throw unwrapError;
    const cipher = new Uint8Array(await stored.data.arrayBuffer()); const tag = fromB64(doc.auth_tag); const sealed = new Uint8Array(cipher.length + tag.length); sealed.set(cipher); sealed.set(tag, cipher.length);
    const key = await crypto.subtle.importKey("raw", fromB64(rawKey), "AES-GCM", false, ["decrypt"]);
    const pdf = await crypto.subtle.decrypt({ name: "AES-GCM", iv: fromB64(doc.nonce) }, key, sealed);
    await service.from("audit_events").insert({ organization_id: grant.organization_id, actor_user_id: grant.requested_by, event_type: "document.downloaded", entity_type: "secure_document", entity_id: doc.id });
    return new Response(pdf, { headers: { "Content-Type": "application/pdf", "Content-Disposition": "attachment; filename=offer-letter.pdf", "Cache-Control": "no-store, private", "X-Content-Type-Options": "nosniff" } });
  } catch { return new Response("Unable to download document", { status: 500 }); }
});
