import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";
const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type"};
Deno.serve(async(req:Request)=>{
 if(req.method==='OPTIONS')return new Response('ok',{headers:cors});
 try{
  const auth=req.headers.get('Authorization')??'';const url=Deno.env.get('SUPABASE_URL')!;
  const userClient=createClient(url,Deno.env.get('SUPABASE_ANON_KEY')!,{global:{headers:{Authorization:auth}},auth:{persistSession:false}});
  const {data:{user}}=await userClient.auth.getUser();if(!user)return Response.json({error:'Authentication required'},{status:401,headers:cors});
  const body=await req.json();const member=await userClient.from('organization_members').select('organization_id,role').eq('user_id',user.id).eq('organization_id',body.organizationId).eq('active',true).single();
  if(member.error||member.data.role!=='organization_admin')return Response.json({error:'Access denied'},{status:403,headers:cors});
  const existing=await userClient.rpc('assign_organization_role',{p_organization_id:body.organizationId,p_email:String(body.email).trim().toLowerCase(),p_role:body.role});
  if(!existing.error)return Response.json({status:'assigned'},{headers:cors});
  if(!String(existing.error.message??'').includes('must accept'))throw existing.error;
  const service=createClient(url,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,{auth:{persistSession:false}});
  const invited=await service.auth.admin.inviteUserByEmail(String(body.email).trim().toLowerCase(),{redirectTo:String(body.redirectTo??'')||undefined});if(invited.error)throw invited.error;
  const added=await service.from('organization_members').upsert({organization_id:body.organizationId,user_id:invited.data.user.id,role:body.role,active:true,created_by:user.id},{onConflict:'organization_id,user_id'});if(added.error)throw added.error;
  await service.from('audit_events').insert({organization_id:body.organizationId,actor_user_id:user.id,event_type:'member.invited',entity_type:'user',entity_id:invited.data.user.id,metadata:{role:body.role}});
  return Response.json({status:'invited'},{headers:cors});
 }catch(e){return Response.json({error:e instanceof Error?e.message:'Invitation failed'},{status:400,headers:cors});}
});
