import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";
import { PDFDocument, StandardFonts, rgb } from "npm:pdf-lib@1.17.1";
import { organisationLogoBase64 } from "./logo.ts";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
const url = Deno.env.get("SUPABASE_URL")!;
const publishable = Deno.env.get("SUPABASE_ANON_KEY")!;
const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const service = createClient(url, serviceKey, { auth: { persistSession: false } });

const b64 = (v: Uint8Array) => btoa(String.fromCharCode(...v));
const safe = (v: unknown) => String(v ?? "").replace(/[\r\n]+/g, " ").trim();

async function sha256(value: string) {
  const bytes = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return [...new Uint8Array(bytes)].map((x) => x.toString(16).padStart(2, "0")).join("");
}

function lines(text: string, width = 88) {
  const words = text.split(/\s+/); const out: string[] = []; let row = "";
  for (const word of words) {
    if (`${row} ${word}`.trim().length > width) { if (row) out.push(row); row = word; }
    else row = `${row} ${word}`.trim();
  }
  if (row) out.push(row); return out;
}

async function makePdf(snapshot: Record<string, unknown>, annexureOnly = false) {
  const pdf = await PDFDocument.create();
  const regular = await pdf.embedFont(StandardFonts.Helvetica);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);
  const logo = await pdf.embedPng(Uint8Array.from(atob(organisationLogoBase64), (char) => char.charCodeAt(0)));
  const candidate = snapshot.candidate_snapshot as Record<string, unknown>;
  const result = snapshot.result_snapshot as Record<string, unknown>;
  const amount = (value: unknown) => Math.round(Number(value ?? 0)).toLocaleString("en-IN");
  const centerText = (page: ReturnType<PDFDocument["addPage"]>, text: string, left: number, right: number, y: number, size: number, font = regular) => {
    const width = font.widthOfTextAtSize(text, size);
    page.drawText(text, { x: left + (right - left - width) / 2, y, size, font, color: rgb(0.08, 0.20, 0.24) });
  };
  const cellText = (page: ReturnType<PDFDocument["addPage"]>, text: string, left: number, right: number, bottom: number, height: number, size: number, font = regular) => {
    const width = font.widthOfTextAtSize(text, size);
    page.drawText(text, {
      x: left + (right - left - width) / 2,
      y: bottom + (height - size) / 2 + 1.4,
      size,
      font,
      color: rgb(0.08, 0.20, 0.24),
    });
  };
  const wrapByWidth = (text: string, font: typeof regular, size: number, maxWidth: number) => {
    const words = text.trim().split(/\s+/); const wrapped: string[][] = []; let row: string[] = [];
    for (const word of words) {
      const candidate = [...row, word].join(" ");
      if (row.length && font.widthOfTextAtSize(candidate, size) > maxWidth) { wrapped.push(row); row = [word]; }
      else row.push(word);
    }
    if (row.length) wrapped.push(row); return wrapped;
  };
  const drawJustifiedParagraph = (page: ReturnType<PDFDocument["addPage"]>, text: string, x: number, top: number, maxWidth: number, size: number, font = regular) => {
    const wrapped = wrapByWidth(text, font, size, maxWidth); let y = top;
    wrapped.forEach((words, index) => {
      const last = index === wrapped.length - 1;
      if (!last && words.length > 1) {
        const wordsWidth = words.reduce((sum, word) => sum + font.widthOfTextAtSize(word, size), 0);
        const gap = (maxWidth - wordsWidth) / (words.length - 1); let cursor = x;
        for (const word of words) { page.drawText(word, { x: cursor, y, size, font, color: rgb(0.08, 0.20, 0.24) }); cursor += font.widthOfTextAtSize(word, size) + gap; }
      } else page.drawText(words.join(" "), { x, y, size, font, color: rgb(0.08, 0.20, 0.24) });
      y -= 15;
    });
    return y - 9;
  };
  if (!annexureOnly) {
  const page1 = pdf.addPage([595.28, 841.89]);
  page1.drawImage(logo, { x: 425, y: 789, width: 125, height: 26 });
  page1.drawLine({ start: { x: 44, y: 775 }, end: { x: 551, y: 775 }, thickness: 0.7, color: rgb(0.48, 0.58, 0.59) });
  centerText(page1, "OFFER OF EMPLOYMENT", 44, 551, 742, 22, bold);
  page1.drawText(`Date: ${new Date().toISOString().slice(0, 10)}`, { x: 442, y: 714, size: 9, font: regular });
  const bodyLeft = 62;
  const bodyRight = 533;
  page1.drawText("To,", { x: bodyLeft, y: 700, size: 10.5, font: regular, color: rgb(0.08, 0.20, 0.24) });
  page1.drawText(safe(candidate.candidate_name), { x: bodyLeft, y: 684, size: 10.5, font: bold, color: rgb(0.08, 0.20, 0.24) });
  page1.drawText(safe(candidate.designation), { x: bodyLeft, y: 668, size: 10.5, font: regular, color: rgb(0.08, 0.20, 0.24) });
  page1.drawText(safe(candidate.department), { x: bodyLeft, y: 652, size: 10.5, font: regular, color: rgb(0.08, 0.20, 0.24) });
  let y = 622;
  const annualCtc = Number(result.monthly_ctc ?? 0) * 12;
  const paragraphs = [
    `Dear ${safe(candidate.candidate_name)},`,
    "Greetings from Ambuja Neotia Healthcare Venture Limited!!",
    `We are pleased to inform you that our Interview Committee has approved your appointment as ${safe(candidate.designation)} in ${safe(candidate.department)}.`,
    `As discussed, we would be offering you a CTC of INR. ${amount(annualCtc)}/- per annum.`,
    "Your offer letter is enclosed herewith.",
    "Please find attached list of documents that you need to carry at the time of your joining.",
    "You are requested to visit the hospital before your date of joining to complete your Pre-employment Health Check-up.",
    "Feel free to get back to the undersigned for any further clarification.",
    "Kindly send us the acceptance of the offer letter. Awaiting your early response.",
  ];
  for (const paragraph of paragraphs) {
    y = drawJustifiedParagraph(page1, paragraph, bodyLeft, y, bodyRight - bodyLeft, 10.5, regular);
  }
  page1.drawText("Regards,", { x: bodyLeft, y: 116, size: 10.5, font: regular, color: rgb(0.08, 0.20, 0.24) });
  page1.drawText("Recruiter Name || Designation of Recruiter", { x: bodyLeft, y: 88, size: 10.5, font: bold, color: rgb(0.08, 0.20, 0.24) });
  }
  const date = (value: unknown) => {
    const parsed = new Date(`${safe(value)}T00:00:00Z`);
    return Number.isNaN(parsed.getTime()) ? safe(value) : parsed.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric", timeZone: "UTC" });
  };
  const experience = Number(candidate.experience_months ?? 0);
  const experienceText = `${Math.floor(experience / 12)} Year(s) ${experience % 12} Month(s)`;

  const page2 = pdf.addPage([595.28, 841.89]);
  const ink = rgb(0.08, 0.20, 0.24);
  const accent = rgb(0.06, 0.34, 0.38);
  const pale = rgb(0.91, 0.95, 0.95);
  const line = rgb(0.48, 0.58, 0.59);
  page2.drawRectangle({ x: 28, y: 28, width: 539, height: 786, borderWidth: 1.2, borderColor: ink });
  page2.drawText("ANNEXURE - I", { x: 251, y: 785, size: 10, font: bold, color: accent });
  page2.drawText("PAY FIXATION SHEET", { x: 193, y: 760, size: 18, font: bold, color: ink });
  page2.drawLine({ start: { x: 193, y: 756 }, end: { x: 402, y: 756 }, thickness: 1, color: accent });

  const details: Array<[string, string]> = [
    ["Name", safe(candidate.candidate_name).toUpperCase()],
    ["Date of Birth", date(candidate.date_of_birth)],
    ["Company", safe(candidate.company).toUpperCase()],
    ["Grade", safe(candidate.grade).toUpperCase()],
    ["Qualification", safe(candidate.qualification).toUpperCase()],
    ["Experience", experienceText],
    ["Designation", safe(candidate.designation).toUpperCase()],
    ["Department", safe(candidate.department).toUpperCase()],
    ["Date of Joining", date(candidate.date_of_joining)],
  ];
  let detailY = 727;
  for (const [label, value] of details) {
    page2.drawRectangle({ x: 48, y: detailY - 18, width: 184, height: 23, color: pale, borderWidth: 0.5, borderColor: line });
    page2.drawRectangle({ x: 232, y: detailY - 18, width: 315, height: 23, borderWidth: 0.5, borderColor: line });
    page2.drawText(label, { x: 55, y: detailY - 10, size: 8.5, font: bold, color: ink });
    const valueWidth = bold.widthOfTextAtSize(value, 8.5);
    page2.drawText(value, { x: 232 + Math.max(10, (315 - valueWidth) / 2), y: detailY - 10, size: 8.5, font: bold, color: ink });
    detailY -= 27;
  }

  const components = (result.components as Array<Record<string, unknown>> ?? []).filter((c) => c.type !== "reference");
  const tableTop = 466;
  const rowH = Math.min(17.5, 210 / Math.max(components.length, 1));
  const xs = [48, 300, 384, 466, 547];
  page2.drawRectangle({ x: xs[0], y: tableTop, width: xs[4] - xs[0], height: 27, color: pale, borderWidth: 0.7, borderColor: line });
  for (const x of xs.slice(1, -1)) page2.drawLine({ start: { x, y: tableTop }, end: { x, y: tableTop + 27 }, thickness: 0.7, color: line });
  cellText(page2, "Salary Components", xs[0], xs[1], tableTop, 27, 9, bold);
  cellText(page2, "Yearly Breakup", xs[1], xs[2], tableTop, 27, 7.5, bold);
  cellText(page2, "Monthly Breakup", xs[2], xs[3], tableTop, 27, 7.5, bold);
  cellText(page2, "Monthly Deduction", xs[3], xs[4], tableTop, 27, 7.2, bold);
  let rowY = tableTop;
  for (const c of components) {
    rowY -= rowH;
    page2.drawRectangle({ x: xs[0], y: rowY, width: xs[4] - xs[0], height: rowH, borderWidth: 0.45, borderColor: line });
    for (const x of xs.slice(1, -1)) page2.drawLine({ start: { x, y: rowY }, end: { x, y: rowY + rowH }, thickness: 0.45, color: line });
    const isDeduction = c.type === "deduction";
    page2.drawText(safe(c.label), { x: 53, y: rowY + 6, size: 7.8, font: regular, color: ink });
    cellText(page2, amount(c.annual_exact), xs[1], xs[2], rowY, rowH, 7.8);
    if (isDeduction) cellText(page2, amount(c.monthly_display), xs[3], xs[4], rowY, rowH, 7.8);
    else cellText(page2, amount(c.monthly_display), xs[2], xs[3], rowY, rowH, 7.8);
  }

  const totalsY = rowY - 15;
  page2.drawRectangle({ x: 48, y: totalsY - 24, width: 318, height: 24, color: pale, borderWidth: 0.7, borderColor: line });
  page2.drawText("Yearly CTC", { x: 55, y: totalsY - 16, size: 8.5, font: bold, color: ink });
  centerText(page2, amount(result.annual_ctc), 270, 366, totalsY - 16, 8.5, bold);
  const deductionsBeforeTax = components.filter((c) => c.type === "deduction" && c.key !== "professional_tax").reduce((sum, c) => sum + Number(c.monthly_exact ?? 0), 0);
  const beforeTaxes = Number(result.monthly_gross ?? 0) - deductionsBeforeTax;
  const summaryTop = totalsY - 40;
  page2.drawRectangle({ x: 48, y: summaryTop - 76, width: 318, height: 76, borderWidth: 0.7, borderColor: line });
  const totals: Array<[string, unknown]> = [["CTC Breakup per Month",result.monthly_ctc],["Monthly Gross Salary",result.monthly_gross],["Monthly Take Home (Before Taxes)",beforeTaxes],["Monthly Take Home (After Taxes)",result.net_take_home]];
  let totalRowY = summaryTop - 15;
  for (const [label, value] of totals) {
    page2.drawText(label, { x: 55, y: totalRowY, size: 8.2, font: regular, color: ink });
    centerText(page2, amount(value), 270, 366, totalRowY, 8.2, bold);
    totalRowY -= 19;
  }
  page2.drawText("For ORGANISATION / COMPANY NAME", { x: 55, y: 92, size: 7.8, font: bold, color: ink });
  page2.drawText("Authorised Signatory", { x: 55, y: 50, size: 7.8, font: regular, color: ink });

  if (!annexureOnly) {
  const page3 = pdf.addPage([595.28, 841.89]);
  page3.drawImage(logo, { x: 425, y: 789, width: 125, height: 26 });
  page3.drawLine({ start: { x: 44, y: 775 }, end: { x: 551, y: 775 }, thickness: 0.7, color: line });
  page3.drawText("ANHVL/HR/FM/M-0/007", { x: 414, y: 748, size: 8.5, font: regular, color: ink });
  centerText(page3, "JOINING CHECK LIST", 44, 551, 729, 15, bold);
  page3.drawLine({ start: { x: 218, y: 725 }, end: { x: 377, y: 725 }, thickness: 0.7, color: ink });
  let checklistY = 690;
  const intro = [
    "Following is a checklist mentioning the necessary documents to be submitted on the day of joining.",
    "In order to expedite the joining formalities / process, we request you to carry the originals of the documents and their respective photocopies with you on the date of joining for verification and submission to the Department of Human Resources.",
  ];
  for (const paragraph of intro) {
    for (const lineText of lines(paragraph, 88)) {
      page3.drawText(lineText, { x: 58, y: checklistY, size: 10.2, font: bold, color: ink });
      checklistY -= 15;
    }
    checklistY -= 14;
  }
  const checklist = [
    "Curriculum Vitae",
    "Xth (SSC), XIIth (HSC), Graduation, Post-Graduation Mark-sheets and Professional Certificates.",
    "Date of Birth Proof (School Leaving Certificate or any of the documents mentioned hereinabove).",
    "Driving Licence / Voter ID Card / Passport Copy.",
    "PAN Card.",
    "Aadhaar Card.",
    "Relieving letter and / or acceptance of resignation from the previous employer.",
    "Appointment Letter and Promotion Letter (if applicable).",
    "Last three months' salary slips.",
    "Provident Fund account details (in case the account needs to be transferred).",
    "3 passport-size photographs.",
    "Cancelled cheque (for Visiting Consultant).",
  ];
  for (const item of checklist) {
    page3.drawRectangle({ x: 61, y: checklistY + 1, width: 7, height: 7, borderWidth: 0.7, borderColor: accent });
    const itemLines = lines(item, 80);
    for (const [index, itemLine] of itemLines.entries()) {
      page3.drawText(itemLine, { x: 78, y: checklistY, size: 9.5, font: regular, color: ink });
      if (index < itemLines.length - 1) checklistY -= 13;
    }
    checklistY -= 18;
  }
  page3.drawText("All photocopies are required to be SELF ATTESTED.", { x: 58, y: checklistY - 2, size: 10.5, font: bold, color: ink });
  }
  return await pdf.save();
}

async function processJob(jobId: string) {
  const claimed = await service.from("document_jobs").update({ status: "processing", started_at: new Date().toISOString() }).eq("id", jobId).eq("status", "queued").select("*").maybeSingle();
  if (claimed.error || !claimed.data) return;
  try {
    const { data: snapshot, error } = await service.from("ctc_snapshots").select("*").eq("id", claimed.data.snapshot_id).single();
    if (error) throw error;
    const pdf = await makePdf(snapshot, String(claimed.data.idempotency_key ?? "").startsWith("annexure-only:"));
    const dataKey = crypto.getRandomValues(new Uint8Array(32));
    const nonce = crypto.getRandomValues(new Uint8Array(12));
    const key = await crypto.subtle.importKey("raw", dataKey, "AES-GCM", false, ["encrypt"]);
    const sealed = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv: nonce }, key, pdf));
    const tag = sealed.slice(-16); const ciphertext = sealed.slice(0, -16);
    const { data: wrapped, error: wrapError } = await service.rpc("wrap_document_key", { p_plain_key: b64(dataKey) });
    if (wrapError) throw wrapError;
    const path = `${claimed.data.organization_id}/${claimed.data.snapshot_id}/${crypto.randomUUID()}.bin`;
    const upload = await service.storage.from("offer-documents").upload(path, ciphertext, { contentType: "application/octet-stream", upsert: false });
    if (upload.error) throw upload.error;
    const digest = [...new Uint8Array(await crypto.subtle.digest("SHA-256", pdf))].map((x) => x.toString(16).padStart(2, "0")).join("");
    const inserted = await service.from("secure_documents").insert({ organization_id: claimed.data.organization_id, snapshot_id: claimed.data.snapshot_id, job_id: jobId, storage_path: path, cipher_algorithm: "AES-256-GCM", encrypted_data_key: wrapped, nonce: b64(nonce), auth_tag: b64(tag), content_sha256: digest, created_by: claimed.data.requested_by });
    if (inserted.error) { await service.storage.from("offer-documents").remove([path]); throw inserted.error; }
    await service.from("document_jobs").update({ status: "ready", completed_at: new Date().toISOString(), attempt_count: claimed.data.attempt_count + 1, last_error: null }).eq("id", jobId);
  } catch (error) {
    await service.from("document_jobs").update({ status: "failed", attempt_count: claimed.data.attempt_count + 1, last_error: error instanceof Error ? error.message.slice(0, 500) : "Document generation failed" }).eq("id", jobId);
  }
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const auth = req.headers.get("Authorization") ?? "";
    const userClient = createClient(url, publishable, { global: { headers: { Authorization: auth } }, auth: { persistSession: false } });
    const { data: { user } } = await userClient.auth.getUser();
    if (!user) return Response.json({ error: "Authentication required" }, { status: 401, headers: cors });
    const body = await req.json();
    if (body.action === "process") {
      const visible = await userClient.from("document_jobs").select("id,status").eq("id", body.jobId).single();
      if (visible.error) return Response.json({ error: "Job not found" }, { status: 404, headers: cors });
      if (visible.data.status === "queued") EdgeRuntime.waitUntil(processJob(body.jobId));
      return Response.json({ jobId: body.jobId, status: visible.data.status }, { status: 202, headers: cors });
    }
    if (body.action === "issue-download") {
      const visible = await userClient.from("secure_documents").select("id,organization_id").eq("id", body.documentId).single();
      if (visible.error) return Response.json({ error: "Document not found" }, { status: 404, headers: cors });
      const token = b64(crypto.getRandomValues(new Uint8Array(32))).replaceAll("+", "-").replaceAll("/", "_").replaceAll("=", "");
      const tokenHash = await sha256(token); const expires = new Date(Date.now() + 5 * 60_000).toISOString();
      const grant = await service.from("document_download_grants").insert({ organization_id: visible.data.organization_id, document_id: visible.data.id, requested_by: user.id, token_hash: tokenHash, expires_at: expires });
      if (grant.error) throw grant.error;
      return Response.json({ url: `${url}/functions/v1/secure-download?token=${encodeURIComponent(token)}`, expiresAt: expires }, { headers: cors });
    }
    return Response.json({ error: "Unsupported action" }, { status: 400, headers: cors });
  } catch (error) { return Response.json({ error: error instanceof Error ? error.message : "Request failed" }, { status: 500, headers: cors }); }
});
