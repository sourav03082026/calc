import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";
const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type"};
const csv=(v:unknown)=>`"${String(v??'').replaceAll('"','""')}"`;
Deno.serve(async(req:Request)=>{
 if(req.method==='OPTIONS')return new Response('ok',{headers:cors});
 try{
  const auth=req.headers.get('Authorization')??'';
  const sb=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_ANON_KEY')!,{global:{headers:{Authorization:auth}},auth:{persistSession:false}});
  const {data:{user}}=await sb.auth.getUser();if(!user)return new Response('Authentication required',{status:401,headers:cors});
  const member=await sb.from('organization_members').select('organization_id,role').eq('user_id',user.id).eq('active',true).single();
  if(member.error||!['organization_admin','payroll_administrator','chro'].includes(member.data.role))return new Response('Access denied',{status:403,headers:cors});
  const body=await req.json().catch(()=>({}));const month=String(body.month??'');
  let query=sb.from('finalized_ctc_export').select('*').eq('organization_id',member.data.organization_id).order('date_of_joining');
  if(/^\d{4}-\d{2}$/.test(month)){const start=`${month}-01`;const d=new Date(`${start}T00:00:00Z`);d.setUTCMonth(d.getUTCMonth()+1);query=query.gte('date_of_joining',start).lt('date_of_joining',d.toISOString().slice(0,10));}
  const {data,error}=await query;if(error)throw error;
  const heads=new Map<string,string>();for(const row of data??[])for(const c of (row.components??[]))if(c.type!=='reference')heads.set(c.key,c.label);
  const fixed=['Offer Reference','Salary Structure','Candidate Name','Date of Birth','Company','Grade','Qualification','Experience (Months)','Designation','Department','Date of Joining','Monthly Gross','Monthly CTC','Net Take Home','Annual CTC'];
  const dynamic=[...heads.values()].flatMap(h=>[`${h} Monthly`,`${h} Annual`]);const lines=[[...fixed,...dynamic].map(csv).join(',')];
  for(const row of data??[]){const byKey=new Map((row.components??[]).map((c:any)=>[c.key,c]));const values:any[]=[row.offer_reference,row.structure_name,row.candidate_name,row.date_of_birth,row.company,row.grade,row.qualification,row.experience_months,row.designation,row.department,row.date_of_joining,Math.round(Number(row.monthly_gross??0)),Math.round(Number(row.monthly_ctc??0)),Math.round(Number(row.net_take_home??0)),Math.round(Number(row.annual_ctc??0))];for(const key of heads.keys()){const c:any=byKey.get(key);values.push(Math.round(Number(c?.monthly_display??0)),Math.round(Number(c?.annual_exact??0)));}lines.push(values.map(csv).join(','));}
  return new Response('\ufeff'+lines.join('\r\n'),{headers:{...cors,'Content-Type':'text/csv; charset=utf-8','Content-Disposition':`attachment; filename="monthly-ctc-${month||'all'}.csv"`,'Cache-Control':'no-store, private'}});
 }catch(e){return Response.json({error:e instanceof Error?e.message:'Export failed'},{status:500,headers:cors});}
});
