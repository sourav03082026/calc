import { CommonModule } from '@angular/common';
import { Component, OnInit, computed, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { createClient, Session, SupabaseClient } from '@supabase/supabase-js';

type View = 'dashboard' | 'calculator' | 'records' | 'reports' | 'settings';
type Role = 'organization_admin' | 'recruiter' | 'payroll_administrator' | 'chro';
type Result = {
  components: Array<{
    key: string;
    label: string;
    type: string;
    monthly_exact: number;
    monthly_display: number;
    annual_exact: number;
  }>;
  monthly_gross: number;
  annual_gross: number;
  monthly_ctc: number;
  annual_ctc: number;
  monthly_deductions: number;
  net_take_home: number;
};

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit {
  private sb: SupabaseClient = createClient(
    'https://vkkhnunpgutvwcjlgoyp.supabase.co',
    'sb_publishable_A_SBQfwgjizySiBYD1tPVQ_dvI0feo2',
    { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } },
  );
  session = signal<Session | null>(null);
  currentUserId = signal('');
  loading = signal(true);
  busy = signal(false);
  message = signal('');
  error = signal('');
  view = signal<View>('dashboard');
  membership = signal<{ organization_id: string; role: Role; organizationName: string } | null>(
    null,
  );
  structures = signal<any[]>([]);
  records = signal<any[]>([]);
  states = signal<any[]>([]);
  structure3Fitments = signal<any[]>([]);
  email = '';
  password = '';
  orgName = 'Organisation / Company Name';
  loginMode: 'signin' | 'reset' = 'signin';
  selectedStructure = signal('');
  caseId = '';
  candidateId = '';
  caseVersion = 1;
  result = signal<Result | null>(null);
  candidate: any = {
    candidate_name: '',
    date_of_birth: '',
    company: '',
    grade: '',
    qualification: '',
    experience_months: null,
    designation: '',
    department: '',
    date_of_joining: '',
    state_code: 'WB',
  };
  inputs: any = {
    monthly_ctc: 25000,
    minimum_wage_monthly: 1200,
    benefit_mode: 'MEDICLAIM',
    bonus_mode: 'ANNUAL',
    advance_bonus_opted: 'Y',
    pf_basis: 'CAPPED',
    attire_annual: 0,
    mediclaim_annual: 0,
    opt_communication: false,
    opt_conveyance: false,
    opt_books: false,
    opt_attire: false,
    opt_entertainment: false,
    opt_meal_card: false,
    opt_lta: false,
    attire_monthly_custom: 0,
    communication_monthly_custom: 0,
    conveyance_monthly_custom: 0,
    books_monthly_custom: 0,
    entertainment_annual_custom: 0,
    meal_card_monthly_custom: 0,
    lta_annual_custom: 0,
  };
  invite = { email: '', role: 'recruiter' as Role };
  currentMonth = new Date().toISOString().slice(0, 7);
  reportMonth = '';
  annexureOnly = false;
  roleLabel = computed(
    () =>
      ({
        organization_admin: 'Organization Admin',
        recruiter: 'Recruiter',
        payroll_administrator: 'Payroll Administrator',
        chro: 'CHRO',
      })[this.membership()?.role ?? 'recruiter'],
  );
  privileged = computed(() =>
    ['organization_admin', 'payroll_administrator', 'chro'].includes(this.membership()?.role ?? ''),
  );
  canConfigure = computed(() => this.membership()?.role === 'organization_admin');
  currentStructure = computed(() =>
    this.structures().find((s) => s.id === this.selectedStructure()),
  );
  stats = computed(() => {
    const rows = this.records(),
      finalized = rows.filter((r) => r.status === 'finalized'),
      drafts = rows.filter((r) => r.status === 'draft');
    return {
      total: rows.length,
      finalized: finalized.length,
      drafts: drafts.length,
      annual: finalized.reduce((n, r) => n + Number(r.calculated_result?.annual_ctc ?? 0), 0),
    };
  });

  async ngOnInit() {
    const { data } = await this.sb.auth.getSession();
    this.session.set(data.session);
    if (data.session) await this.loadWorkspace();
    this.sb.auth.onAuthStateChange(async (_, s) => {
      this.session.set(s);
      if (s) await this.loadWorkspace();
      else this.membership.set(null);
    });
    this.loading.set(false);
  }
  private clear() {
    this.error.set('');
    this.message.set('');
  }
  async signIn() {
    this.clear();
    this.busy.set(true);
    const { error } = await this.sb.auth.signInWithPassword({
      email: this.email,
      password: this.password,
    });
    if (error) this.error.set(error.message);
    this.busy.set(false);
  }
  async resetPassword() {
    this.clear();
    const { error } = await this.sb.auth.resetPasswordForEmail(this.email, {
      redirectTo: location.origin,
    });
    this.message.set(error ? '' : `Password reset instructions sent to ${this.email}`);
    this.error.set(error?.message ?? '');
  }
  async signOut() {
    await this.sb.auth.signOut();
    this.view.set('dashboard');
  }
  async bootstrap() {
    this.clear();
    this.busy.set(true);
    const { error } = await this.sb.rpc('bootstrap_organization', { p_name: this.orgName });
    if (error) this.error.set(error.message);
    else await this.loadWorkspace();
    this.busy.set(false);
  }
  async loadWorkspace() {
    const user = (await this.sb.auth.getUser()).data.user;
    if (!user) return;
    this.currentUserId.set(user.id);
    const member = await this.sb
      .from('organization_members')
      .select('organization_id,role,organizations(name)')
      .eq('user_id', user.id)
      .eq('active', true)
      .maybeSingle();
    if (member.data) {
      const o: any = member.data.organizations;
      this.membership.set({
        organization_id: member.data.organization_id,
        role: member.data.role as Role,
        organizationName: o?.name ?? 'Organisation / Company Name',
      });
      await Promise.all([
        this.loadStructures(),
        this.loadRecords(),
        this.loadStates(),
        this.loadStructure3Fitments(),
      ]);
    }
  }
  async loadStructures() {
    const q = await this.sb
      .from('salary_structure_versions')
      .select('id,version_no,declarations_schema,salary_structures!inner(code,name)')
      .eq('active', true)
      .order('version_no', { ascending: false });
    this.structures.set(
      (q.data ?? []).map((v: any) => ({
        id: v.id,
        version: v.version_no,
        code: v.salary_structures.code,
        name: v.salary_structures.name,
        schema: v.declarations_schema,
      })),
    );
    if (!this.selectedStructure() && q.data?.length) {
      this.selectedStructure.set((q.data[0] as any).id);
    }
  }
  async loadStates() {
    const q = await this.sb.from('states').select('code,name').eq('active', true).order('name');
    this.states.set(q.data ?? []);
  }
  async loadStructure3Fitments() {
    const q = await this.sb
      .from('structure_3_fitment_rules')
      .select('*')
      .eq('active', true)
      .order('grade');
    this.structure3Fitments.set(q.data ?? []);
  }
  structure3Fitment() {
    return this.structure3Fitments().find((f) => f.grade === this.candidate.grade);
  }
  onStructure3GradeChanged() {
    this.result.set(null);
    for (const key of [
      'opt_attire','opt_communication','opt_conveyance','opt_books',
      'opt_entertainment','opt_meal_card','opt_lta',
    ]) this.inputs[key] = false;
    for (const key of [
      'attire_monthly_custom','communication_monthly_custom','conveyance_monthly_custom',
      'books_monthly_custom','entertainment_annual_custom','meal_card_monthly_custom',
      'lta_annual_custom',
    ]) this.inputs[key] = 0;
  }
  setStructure3Option(optionKey: string, amountKey: string, opted: boolean, maximum: number | null) {
    this.inputs[optionKey] = opted;
    this.inputs[amountKey] = opted
      ? maximum === null ? null : Math.round(Number(maximum))
      : 0;
    this.result.set(null);
  }
  structure3AmountChanged() {
    this.result.set(null);
  }
  onStructureChanged() {
    this.result.set(null);
    if (this.currentStructure()?.code === 'STRUCTURE_3') {
      if (!this.structure3Fitment()) this.candidate.grade = '';
      this.inputs.benefit_mode = 'MEDICLAIM';
      this.inputs.minimum_wage_monthly = 0;
      this.inputs.advance_bonus_opted = 'N';
      if (this.inputs.bonus_mode === 'MONTHLY') this.inputs.bonus_mode = 'OFF';
    }
  }
  async loadRecords() {
    const q = await this.sb
      .from('ctc_cases')
      .select(
        'id,status,version,offer_reference,updated_at,finalized_at,owner_user_id,calculated_result,inputs,structure_version_id,candidate_id,candidates(candidate_name,date_of_birth,company,grade,qualification,experience_months,designation,department,date_of_joining,state_code)',
      )
      .in('status', ['draft', 'finalized'])
      .order('updated_at', { ascending: false });
    this.records.set(q.data ?? []);
  }
  private normalizedInputs() {
    const v = { ...this.inputs, grade: this.candidate.grade };
    if (this.currentStructure()?.code === 'STRUCTURE_3') v.benefit_mode = 'MEDICLAIM';
    for (const k of [
      'monthly_ctc',
      'minimum_wage_monthly',
      'attire_annual',
      'mediclaim_annual',
    ])
      v[k] = Math.round(Number(v[k] ?? 0));
    for (const k of [
      'attire_monthly_custom','communication_monthly_custom','conveyance_monthly_custom',
      'books_monthly_custom','entertainment_annual_custom','meal_card_monthly_custom',
      'lta_annual_custom',
    ]) v[k] = v[k] === null || v[k] === '' ? null : Math.round(Number(v[k]));
    return v;
  }
  private declarationsValid() {
    const isStructure3 = this.currentStructure()?.code === 'STRUCTURE_3';
    if (isStructure3) this.inputs.benefit_mode = 'MEDICLAIM';
    if (isStructure3 && !this.structure3Fitment()) {
      this.error.set('Select a valid Structure 3 grade.');
      return false;
    }
    if (isStructure3) {
      const f = this.structure3Fitment();
      const limits: Array<[string, string, number]> = [
        ['opt_attire','attire_monthly_custom',Number(f.attire_monthly)],
        ['opt_communication','communication_monthly_custom',Number(f.communication_monthly)],
        ['opt_conveyance','conveyance_monthly_custom',Number(f.conveyance_monthly)],
        ['opt_books','books_monthly_custom',Number(f.books_monthly)],
        ['opt_entertainment','entertainment_annual_custom',Number(f.entertainment_annual)],
        ['opt_meal_card','meal_card_monthly_custom',Number(f.meal_card_monthly)],
      ];
      for (const [optionKey, amountKey, maximum] of limits) {
        const value = Number(this.inputs[amountKey]);
        if (this.inputs[optionKey] && (!Number.isFinite(value) || value < 0 || value > maximum)) {
          this.error.set('A customized reimbursement must be between zero and its grade-based maximum.');
          return false;
        }
      }
      const lta = this.inputs.lta_annual_custom;
      if (this.inputs.opt_lta && lta !== null && lta !== '' && Number(lta) < 0) {
        this.error.set('The customized LTA amount cannot be negative.');
        return false;
      }
    }
    if ((isStructure3 || this.inputs.benefit_mode === 'MEDICLAIM') && Number(this.inputs.mediclaim_annual) <= 0) {
      this.error.set('Enter the annual mediclaim premium amount.');
      return false;
    }
    return true;
  }
  async preview() {
    this.clear();
    if (!this.membership() || !this.selectedStructure()) return;
    if (!this.declarationsValid()) return;
    this.busy.set(true);
    const calculator =
      this.currentStructure()?.code === 'STRUCTURE_3'
        ? 'calculate_ctc_structure_3'
        : 'calculate_ctc';
    const { data, error } = await this.sb.rpc(calculator, {
      p_organization_id: this.membership()!.organization_id,
      p_structure_version_id: this.selectedStructure(),
      p_inputs: this.normalizedInputs(),
      p_effective_date: this.candidate.date_of_joining || new Date().toISOString().slice(0, 10),
      p_state_code: this.candidate.state_code,
    });
    if (error) this.error.set(error.message);
    else this.result.set(data as Result);
    this.busy.set(false);
  }
  async saveDraft() {
    this.clear();
    if (!this.declarationsValid()) return;
    const org = this.membership(),
      user = (await this.sb.auth.getUser()).data.user;
    if (!org || !user) return;
    this.busy.set(true);
    try {
      if (!this.candidateId) {
        const c = await this.sb
          .from('candidates')
          .insert({
            ...this.candidate,
            experience_months: this.candidate.experience_months
              ? Number(this.candidate.experience_months)
              : null,
            organization_id: org.organization_id,
            owner_user_id: user.id,
          })
          .select('id')
          .single();
        if (c.error) throw c.error;
        this.candidateId = c.data.id;
      } else {
        const c = await this.sb
          .from('candidates')
          .update({
            ...this.candidate,
            experience_months: this.candidate.experience_months
              ? Number(this.candidate.experience_months)
              : null,
          })
          .eq('id', this.candidateId);
        if (c.error) throw c.error;
      }
      if (!this.caseId) {
        const c = await this.sb
          .from('ctc_cases')
          .insert({
            organization_id: org.organization_id,
            candidate_id: this.candidateId,
            owner_user_id: user.id,
            structure_version_id: this.selectedStructure(),
            inputs: this.normalizedInputs(),
            offer_reference: `OFR-${new Date().getFullYear()}-${crypto.randomUUID().slice(0, 8).toUpperCase()}`,
          })
          .select('id,version')
          .single();
        if (c.error) throw c.error;
        this.caseId = c.data.id;
        this.caseVersion = c.data.version;
      } else {
        const c = await this.sb.rpc('save_ctc_draft', {
          p_case_id: this.caseId,
          p_expected_version: this.caseVersion,
          p_inputs: this.normalizedInputs(),
        });
        if (c.error) throw c.error;
        this.caseVersion = c.data.version;
      }
      const calculated = await this.sb.rpc('recalculate_ctc_case', {
        p_case_id: this.caseId,
        p_expected_version: this.caseVersion,
      });
      if (calculated.error) throw calculated.error;
      this.caseVersion = calculated.data.version;
      this.result.set(calculated.data.calculated_result as Result);
      this.message.set('Draft saved and recalculated securely.');
      await this.loadRecords();
    } catch (e: any) {
      this.error.set(e.message ?? 'Unable to save draft');
    } finally {
      this.busy.set(false);
    }
  }
  async finalize() {
    // Finalization must always use a freshly persisted, server-verified result.
    // This also repairs drafts whose earlier recalculation failed and prevents
    // unsaved form changes from being finalized against an older calculation.
    await this.saveDraft();
    if (!this.caseId || this.error() || !this.result()) return;
    this.clear();
    this.busy.set(true);
    const done = await this.sb.rpc('finalize_ctc_case', {
      p_case_id: this.caseId,
      p_expected_version: this.caseVersion,
      p_idempotency_key: crypto.randomUUID(),
    });
    if (done.error) {
      this.error.set(done.error.message);
      this.busy.set(false);
      return;
    }
    const job = await this.sb
      .from('document_jobs')
      .select('id')
      .eq('snapshot_id', done.data)
      .single();
    if (job.data) {
      const processing = await this.sb.functions.invoke('document-jobs', {
        body: { action: 'process', jobId: job.data.id },
      });
      if (processing.error) {
        this.error.set(`CTC finalized, but document generation could not start: ${processing.error.message}`);
        this.busy.set(false);
        await this.loadRecords();
        return;
      }
    }
    this.message.set(
      'CTC finalized. The encrypted offer letter is being generated asynchronously.',
    );
    this.busy.set(false);
    await this.loadRecords();
  }
  newDraft() {
    this.caseId = '';
    this.candidateId = '';
    this.caseVersion = 1;
    this.result.set(null);
    this.candidate = {
      candidate_name: '',
      date_of_birth: '',
      company: '',
      grade: '',
      qualification: '',
      experience_months: null,
      designation: '',
      department: '',
      date_of_joining: '',
      state_code: 'WB',
    };
    this.inputs = {
      monthly_ctc: 25000,
      minimum_wage_monthly: 1200,
      benefit_mode: 'MEDICLAIM',
      bonus_mode: 'ANNUAL',
      advance_bonus_opted: 'Y',
      pf_basis: 'CAPPED',
      attire_annual: 0,
      mediclaim_annual: 0,
      opt_communication: false,
      opt_conveyance: false,
      opt_books: false,
      opt_attire: false,
      opt_entertainment: false,
      opt_meal_card: false,
      opt_lta: false,
      attire_monthly_custom: 0,
      communication_monthly_custom: 0,
      conveyance_monthly_custom: 0,
      books_monthly_custom: 0,
      entertainment_annual_custom: 0,
      meal_card_monthly_custom: 0,
      lta_annual_custom: 0,
    };
    this.view.set('calculator');
  }
  openDraft(record: any) {
    if (record.status !== 'draft') return;
    this.caseId = record.id;
    this.candidateId = record.candidate_id;
    this.caseVersion = record.version;
    this.selectedStructure.set(record.structure_version_id);
    this.candidate = {
      candidate_name: record.candidates?.candidate_name ?? '',
      date_of_birth: record.candidates?.date_of_birth ?? '',
      company: record.candidates?.company ?? '',
      grade: record.candidates?.grade ?? '',
      qualification: record.candidates?.qualification ?? '',
      experience_months: record.candidates?.experience_months ?? null,
      designation: record.candidates?.designation ?? '',
      department: record.candidates?.department ?? '',
      date_of_joining: record.candidates?.date_of_joining ?? '',
      state_code: record.candidates?.state_code ?? 'WB',
    };
    this.inputs = { ...this.inputs, ...(record.inputs ?? {}) };
    if (this.currentStructure()?.code === 'STRUCTURE_3') this.inputs.benefit_mode = 'MEDICLAIM';
    this.result.set(record.calculated_result as Result | null);
    this.view.set('calculator');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  canManageOwn(record: any) {
    return (
      record.owner_user_id === this.currentUserId() &&
      ['recruiter', 'organization_admin'].includes(this.membership()?.role ?? '')
    );
  }
  async deleteDraft(record: any) {
    if (!this.canManageOwn(record) || record.status !== 'draft') return;
    if (!confirm(`Delete the draft CTC for ${record.candidates?.candidate_name ?? 'this candidate'}? This draft cannot be recovered.`)) return;
    this.clear();
    this.busy.set(true);
    const { error } = await this.sb.rpc('delete_own_ctc_draft', {
      p_case_id: record.id,
      p_expected_version: record.version,
    });
    if (error) this.error.set(error.message);
    else {
      if (this.caseId === record.id) this.newDraft();
      this.message.set('Draft CTC deleted securely.');
      await this.loadRecords();
    }
    this.busy.set(false);
  }
  async cancelFinalized(record: any) {
    if (!this.canManageOwn(record) || record.status !== 'finalized') return;
    if (!confirm(`Cancel and archive the finalized CTC for ${record.candidates?.candidate_name ?? 'this candidate'}? Its immutable audit snapshot will be retained.`)) return;
    this.clear();
    this.busy.set(true);
    const { error } = await this.sb.rpc('cancel_own_finalized_ctc', {
      p_case_id: record.id,
      p_expected_version: record.version,
    });
    if (error) this.error.set(error.message);
    else {
      this.message.set('Finalized CTC cancelled and archived securely.');
      await this.loadRecords();
    }
    this.busy.set(false);
  }
  async assignRole() {
    this.clear();
    const m = this.membership();
    if (!m) return;
    this.busy.set(true);
    const { error } = await this.sb.functions.invoke('invite-user', {
      body: { organizationId: m.organization_id, email: this.invite.email, role: this.invite.role, redirectTo: location.origin },
    });
    if (error) this.error.set(error.message);
    else {
      this.message.set('Role assigned successfully. Existing users are updated immediately.');
      this.invite.email = '';
      await this.loadWorkspace();
    }
    this.busy.set(false);
  }
  async downloadPayroll() {
    this.clear();
    const token = this.session()?.access_token;
    if (!token) return;
    this.busy.set(true);
    try {
      const response = await fetch(
        'https://vkkhnunpgutvwcjlgoyp.supabase.co/functions/v1/payroll-export',
        {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({ month: this.reportMonth }),
        },
      );
      if (!response.ok) throw new Error(await response.text());
      const href = URL.createObjectURL(await response.blob());
      const a = document.createElement('a');
      a.href = href;
      a.download = `monthly-ctc-${this.reportMonth}.csv`;
      a.click();
      URL.revokeObjectURL(href);
    } catch (e: any) {
      this.error.set(e.message ?? 'Export failed');
    } finally {
      this.busy.set(false);
    }
  }
  async downloadOffer(caseId: string) {
    this.clear();
    this.busy.set(true);
    try {
      const snapshot = await this.sb
        .from('ctc_snapshots')
        .select('id')
        .eq('case_id', caseId)
        .order('revision', { ascending: false })
        .limit(1)
        .single();
      if (snapshot.error) throw new Error('The finalized snapshot is not available.');
      let targetJobId = '';
      if (this.annexureOnly) {
        const requested = await this.sb.rpc('request_document_job', {
          p_snapshot_id: snapshot.data.id,
          p_template_id: null,
          p_idempotency_key: `annexure-only:${snapshot.data.id}`,
        });
        if (requested.error) throw requested.error;
        targetJobId = requested.data;
      }
      let docQuery = this.sb.from('secure_documents').select('id').eq('snapshot_id', snapshot.data.id);
      if (targetJobId) docQuery = docQuery.eq('job_id', targetJobId);
      let doc = await docQuery.order('created_at', { ascending: false }).limit(1).maybeSingle();
      if (!doc.data) {
        let jobQuery = this.sb
          .from('document_jobs')
          .select('id,status,last_error')
          .eq('snapshot_id', snapshot.data.id);
        if (targetJobId) jobQuery = jobQuery.eq('id', targetJobId);
        const job = await jobQuery.order('created_at', { ascending: false }).limit(1).maybeSingle();
        if (job.error || !job.data)
          throw new Error('The document generation job is unavailable.');
        if (job.data.status === 'failed')
          throw new Error(job.data.last_error ?? 'Document generation failed.');
        const processing = await this.sb.functions.invoke('document-jobs', {
          body: { action: 'process', jobId: job.data.id },
        });
        if (processing.error) throw processing.error;
        for (let attempt = 0; attempt < 10 && !doc.data; attempt++) {
          await new Promise((resolve) => setTimeout(resolve, 1000));
          let polling = this.sb
            .from('secure_documents')
            .select('id')
            .eq('snapshot_id', snapshot.data.id);
          if (targetJobId) polling = polling.eq('job_id', targetJobId);
          doc = await polling.order('created_at', { ascending: false }).limit(1).maybeSingle();
        }
        if (!doc.data)
          throw new Error(
            'The encrypted offer letter is still being generated. Please try again shortly.',
          );
      }
      const issued = await this.sb.functions.invoke('document-jobs', {
        body: { action: 'issue-download', documentId: doc.data.id },
      });
      if (issued.error || !issued.data?.url)
        throw issued.error ?? new Error('Secure link could not be issued.');
      location.assign(issued.data.url);
    } catch (e: any) {
      this.error.set(e.message ?? 'Download failed');
    } finally {
      this.busy.set(false);
    }
  }
  money(v: any) {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(Number(v ?? 0));
  }
}
