# Secure CTC & Offer Management

Angular 22 + Supabase implementation for recruiter CTC drafting, finalization, dashboards, payroll export, and encrypted offer-letter delivery.

## What is already deployed

- Supabase PostgreSQL schema, RLS, role model, calculation engine, immutable snapshots and audit tables.
- Structure 1 and Structure 2 configuration graphs from the supplied workbooks.
- State-wise, effective-dated Professional Tax data model. The current West Bengal employee slabs are seeded; other states are added as effective-dated schemes rather than code changes.
- Edge Functions: `document-jobs`, `secure-download`, `payroll-export`, and `invite-user`.
- Private `offer-documents` Storage bucket. PDFs are encrypted with a unique AES-256-GCM key; that key is separately wrapped with a Vault-protected key.

## Source layout

- `frontend/` — Angular application and production build.
- `supabase/migrations/` — ordered database migrations.
- `supabase/functions/` — server-side asynchronous document, export and invitation functions.
- `reference/` — extracted, auditable workbook formula/value contracts.

## First administrator

1. In Supabase Dashboard → Authentication → Users, create the first user with their work email and a strong temporary password.
2. Open the Angular app and sign in.
3. The first-time setup screen creates the organisation and makes this account the Organization Administrator.
4. Configure custom SMTP in Supabase before inviting production users. The administrator can then invite recruiters, Payroll Administrators and CHRO users from the app.

## Cloudflare Pages deployment

No IDE is required.

1. Upload this source to a private GitHub repository.
2. In Cloudflare Pages, connect the repository.
3. Framework preset: `Angular`.
4. Root directory: `frontend`.
5. Build command: `npm ci && npm run build`.
6. Output directory: `dist/ctc-secure-frontend/browser`.
7. After the first deployment, add the Cloudflare URL to Supabase Authentication → URL Configuration as the Site URL and an allowed redirect URL.

The frontend contains only the Supabase publishable key. No service-role key, Vault key, document key or other privileged secret is present in the browser bundle.

## Validation status

- Angular production build passes.
- Structure 1 golden example: monthly CTC ₹19,000, gross ₹16,519.940476, Special Allowance ₹1,861.607143, WB P-Tax ₹130.
- Structure 2 golden example: monthly CTC ₹29,000, gross ₹26,935, Monthly Allowance ₹3,976.666667, WB P-Tax ₹150.
- RLS test: recruiter saw only 1 owned candidate; Payroll Administrator saw both organisation candidates.

## Statutory-data discipline

Rates, ceilings, percentages, formulas, state slabs and component labels are versioned data. The evaluator contains only generic mathematical operations and no salary/statutory amounts.

The West Bengal notification dated 18 August 2026 was a proposed amendment with a stated future commencement date. It is deliberately not activated in the database until its final legal status and effective date are confirmed.
